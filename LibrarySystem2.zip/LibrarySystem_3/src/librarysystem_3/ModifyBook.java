package librarysystem_3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ModifyBook {

    private String BookName, BookAuther, eddition, IsReserved, SerialNumber, query;
    private Connection con;
    private Statement state;
    private PreparedStatement prep;
    private ResultSet rs;
    private int Coppies;
    Scanner sc = new Scanner(System.in);

    public ModifyBook(Connection con, Statement state, PreparedStatement prep, ResultSet rs) {
        this.con = con;
        this.state = state;
        this.prep = prep;
        this.rs = rs;
    }

    public boolean ModifyBook() {
        System.out.println("You have to First Provide Some Informatin of Book to Modify It");
        System.out.println("Enter the Name of Book");
        String st1 = sc.nextLine();
        System.out.println("Enter Author Name of Book");
        String st2 = sc.nextLine();
        System.out.println("Enter the Eddition of Book like-->>1st,2nd etc");
        String st3 = sc.nextLine();

        SearchBook sb = new SearchBook(con, state, prep, rs);
        if (sb.Search1(st1, st2, st3)) {
            System.out.println("///Book Found You Can Modified It///");
            System.out.println("Enter the modify Book Name");
            BookName = sc.nextLine();
            System.out.println("Enter the modify Book Author Name");
            BookAuther = sc.nextLine();
            System.out.println("Enter the modify Book Eddition like-->>1st,2nd etc");
            eddition = sc.nextLine();
            System.out.println("Is book reserved like-->>yes,no etc");
            IsReserved = sc.nextLine();
            System.out.println("Enter the modify Book Serial Number");
            SerialNumber = sc.nextLine();
            System.out.println("Number of modify Book copies like-->>1,2,10 etc");
            Coppies = sc.nextInt();
            new DeleteBook(con, state, prep, rs).Delete1(st1, st2, st3);

            query = "insert into addBook(BookName,BookAuther,eddition,IsReserved,SerialNumber,Coppies) values('" + BookName + "','" + BookAuther + "','" + eddition + "','" + IsReserved + "','" + SerialNumber + "','" + Coppies + "')";
            try {
                state = con.createStatement();
                int num = 0;
                num = state.executeUpdate(query);
                if (num > 0) {
                    return true;
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());

            }

        } else {
            System.out.println("Book never found you can't modify");
        }
        return false;
    }
}
