package librarysystem_3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SearchBook {

    private String BookName, BookAuther, eddition, query;
    private Connection con;
    private Statement state;
    private PreparedStatement prep;
    private ResultSet rs;
    Scanner sc = new Scanner(System.in);

    public SearchBook(Connection con, Statement state, PreparedStatement prep, ResultSet rs) {
        this.con = con;
        this.state = state;
        this.prep = prep;
        this.rs = rs;

    }

    public boolean Search() {
        System.out.println("///Search Book by///\n1. Book Name\n2. Isbn Number\n3. Book Auther");
        int check = sc.nextInt();
        System.out.println("djvd" + check);
        sc = new Scanner(System.in);
        if (check == 1) {
            System.out.println("Enter the name of Book");
            String st1 = sc.nextLine();
            query = "select *from addbook where bookname='" + st1 + "';";
        } else if (check == 2) {
            System.out.println("Enter the Isbn Number of Book");
            String st2 = sc.nextLine();
            query = "select *from addbook where isbnnumber='" + st2 + "';";
        } else if (check == 3) {
            System.out.println("Enter the Auther Name of Book");
            String st3 = sc.nextLine();
            query = "select *from addbook where bookauther='" + st3 + "';";
        }
        try {
            state = con.createStatement();
            rs = state.executeQuery(query);
            System.out.println("BookName\t\tBookAuther\t\tIsbnNumver\t\tEddition\t\tIsReserved\t\tSerialNumber\t\tCoppies");
            int num = 0;
            while (rs.next()) {
                num = 1;
                System.out.println(rs.getString("bookname") + "\t\t" + rs.getString("bookauther") + "\t\t" + rs.getString("isbnnumber") + "\t\t" + rs.getString("eddition") + "\t\t" + rs.getString("isreserved") + "\t\t" + rs.getString("Serialnumber") + "\t\t" + rs.getString("coppies"));
            }
            if (num > 0) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(SearchBook.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    public boolean Search1(String st1, String st2, String st3) {

        query = "select *from addbook where bookname='" + st1 + "' and bookauther='" + st2 + "' and eddition='" + st3 + "';";

        try {
            state = con.createStatement();
            rs = state.executeQuery(query);

            int num = 0;
            while (rs.next()) {
                num = 1;
            }
            if (num > 0) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(SearchBook.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
