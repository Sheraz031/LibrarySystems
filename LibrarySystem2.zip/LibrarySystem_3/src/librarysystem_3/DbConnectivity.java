package librarysystem_3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class DbConnectivity {

    private Connection con;
    private Statement state;
    private PreparedStatement prep;
    private ResultSet rs;
    private String db = "librarymanagementsystem";
    private String user = "root";
    private String password = "root";

    public DbConnectivity() {
        if (DataBaseConnection()) {
            System.out.println("Connection Working");
        } else {
            System.out.println("Something wrong in Connection");
        }
    }

    public boolean DataBaseConnection() {
        try {
            //Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + db, user, password);
            state = null;
            prep = null;
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public Statement getState() {
        return state;
    }

    public ResultSet getRs() {
        return rs;
    }

    public PreparedStatement getPrep() {
        return prep;
    }

    public Connection getCon() {
        return con;
    }

    public String getDb() {
        return db;
    }

    public String getPassword() {
        return password;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setRs(ResultSet rs) {
        this.rs = rs;
    }

    public void setState(Statement state) {
        this.state = state;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPrep(PreparedStatement prep) {
        this.prep = prep;
    }

    public void setDb(String db) {
        this.db = db;
    }

    public void setCon(Connection con) {
        this.con = con;
    }
}
