/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysystem_3;

import java.util.Scanner;

/**
 *
 * @author SHERAZ AHMAD
 */
public class LibrarySystem_3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DbConnectivity connectivity = new DbConnectivity();
        while (true) {
            System.out.println("----|||||LIBRARY MANAGEMENT SYSTEM|||||----");
            System.out.println("              --|||MENU|||--");
            System.out.println("'1'--> FOR ADD BOOK");
            System.out.println("'2'--> FOR DELETE BOOK");
            System.out.println("'3'--> FOR SEARCH BOOK");
            System.out.println("'4'--> FOR MODIFY BOOK");
            System.out.println("'5'--> FOR DISPLAY BOOK");
            System.out.println("'6'--> FOR EXIT APPLICATION");
            int select = sc.nextInt();
            switch (select) {
                case 1: {
                    AddBook ab = new AddBook(connectivity.getCon(), connectivity.getState(), connectivity.getPrep(), connectivity.getRs());
                    if (ab.Add()) {
                        System.out.println("Book Added Successfully");
                    }
                    break;
                }
                case 2: {
                            DeleteBook db = new DeleteBook(connectivity.getCon(), connectivity.getState(), connectivity.getPrep(), connectivity.getRs());
        if (db.Delete()) {
            System.out.println("Deleted Successfully");
        }
                  
                    break;
                }
                case 3: {
                      SearchBook sb = new SearchBook(connectivity.getCon(), connectivity.getState(), connectivity.getPrep(), connectivity.getRs());
                    System.out.println(sb.Search());
                    break;
                }
                case 4: {
                    ModifyBook mb = new ModifyBook(connectivity.getCon(), connectivity.getState(), connectivity.getPrep(), connectivity.getRs());
                    System.out.println(mb.ModifyBook());
                    break;
                }
                case 5: {
                    DisplayBook display = new DisplayBook(connectivity.getCon(), connectivity.getState(), connectivity.getPrep(), connectivity.getRs());
                    System.out.println(display.Display());
                    break;
                }
                case 6: {
                    System.out.println("APPLICATION CLOSED");
                    System.exit(0);
                    break;
                }
                default: {
                    System.out.println("Wrong Menu Selected Application Will Run Again");
                }
            }
        }




    }

}
