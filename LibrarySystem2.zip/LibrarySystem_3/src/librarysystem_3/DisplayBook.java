package librarysystem_3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DisplayBook {

    private String BookName, BookAuther, eddition, query;
    private Connection con;
    private Statement state;
    private PreparedStatement prep;
    private ResultSet rs;
    Scanner sc = new Scanner(System.in);

    public DisplayBook(Connection con, Statement state, PreparedStatement prep, ResultSet rs) {
        this.con = con;
        this.state = state;
        this.prep = prep;
        this.rs = rs;

    }

    public boolean Display() {
        query = "select *from addbook";
        try {
            state = con.createStatement();
            rs = state.executeQuery(query);
            System.out.println("BookName\t\tBookAuther\t\tIsbnNumver\t\tEddition\t\tIsReserved\t\tSerialNumber\t\tCoppies");
            int num = 0;
            while (rs.next()) {
                num = 1;
                System.out.println(rs.getString("bookname") + "\t\t" + rs.getString("bookauther") + "\t\t" + rs.getString("isbnnumber") + "\t\t" + rs.getString("eddition") + "\t\t" + rs.getString("isreserved") + "\t\t" + rs.getString("Serialnumber") + "\t\t" + rs.getString("coppies"));
            }
            if (num > 0) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(DisplayBook.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

}
