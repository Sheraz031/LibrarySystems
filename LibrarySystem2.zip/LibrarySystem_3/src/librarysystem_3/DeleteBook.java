/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysystem_3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteBook {

    private String BookName, BookAuther, eddition, query;
    private Connection con;
    private Statement state;
    private PreparedStatement prep;
    private ResultSet rs;
    Scanner sc = new Scanner(System.in);

    public DeleteBook(Connection con, Statement state, PreparedStatement prep, ResultSet rs) {
        this.con = con;
        this.state = state;
        this.prep = prep;
        this.rs = rs;
    }

    public boolean Delete() {
        System.out.println("Enter the Book Name");
        BookName = sc.nextLine();
        System.out.println("Enter the Book Author Name");
        BookAuther = sc.nextLine();
        System.out.println("Enter the Book Eddition like-->>1st,2nd etc");
        eddition = sc.nextLine();
        String q3 = "  SET SQL_SAFE_UPDATES = 1;";
        String q1 = "SET SQL_SAFE_UPDATES = 0;";
        String q2 = "delete from AddBook where BookName='" + BookName + "' and BookAuther='" + BookAuther + "' and Eddition='" + eddition + "';";
        try {
            state = con.createStatement();
            int num = 0;
            state.executeUpdate(q1);
            num = state.executeUpdate(q2);
            state.executeUpdate(q3);
            System.out.println("I am num" + num);
            if (num > 0) {
                return true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());

        }

        return false;
    }

    public boolean Delete1(String st1, String st2, String st3) {

        BookName = st1;

        BookAuther = st2;
        eddition = st3;
        String q3 = "  SET SQL_SAFE_UPDATES = 1;";
        String q1 = "SET SQL_SAFE_UPDATES = 0;";
        String q2 = "delete from AddBook where BookName='" + BookName + "' and BookAuther='" + BookAuther + "' and Eddition='" + eddition + "';";
        try {
            state = con.createStatement();
            int num = 0;
            state.executeUpdate(q1);
            num = state.executeUpdate(q2);
            state.executeUpdate(q3);
            System.out.println("I am num" + num);
            if (num > 0) {
                return true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());

        }

        return false;
    }
}
