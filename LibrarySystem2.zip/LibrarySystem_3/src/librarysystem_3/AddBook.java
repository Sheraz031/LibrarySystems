/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarysystem_3;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AddBook {

    private String BookName, BookAuther, eddition, IsReserved, SerialNumber;
    private Connection con;
    private Statement state;
    private PreparedStatement prep;
    private ResultSet rs;
    private int Coppies;
    private String query = "";
    private Scanner sc = new Scanner(System.in);

    public AddBook(Connection con, Statement state, PreparedStatement prep, ResultSet rs) {
        this.con = con;
        this.state = state;
        this.prep = prep;
        this.rs = rs;
        this.Coppies = Coppies;
    }

    public boolean Add() {
        System.out.println("Enter the Book Name");
        BookName = sc.nextLine();
        System.out.println("Enter the Book Author Name");
        BookAuther = sc.nextLine();
        System.out.println("Enter the Book Eddition like-->>1st,2nd etc");
        eddition = sc.nextLine();
        System.out.println("Is book reserved like-->>yes,no etc");
        IsReserved = sc.nextLine();
        System.out.println("Enter the Book Serial Number");
        SerialNumber = sc.nextLine();
        System.out.println("Number of Book copies like-->>1,2,10 etc");
        Coppies = sc.nextInt();
        query = "insert into addBook(BookName,BookAuther,eddition,IsReserved,SerialNumber,Coppies) values('" + BookName + "','" + BookAuther + "','" + eddition + "','" + IsReserved + "','" + SerialNumber + "','" + Coppies + "')";
        try {
            state = con.createStatement();
            int num = 0;
            num = state.executeUpdate(query);
            if (num > 0) {
                return true;
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());

        }

        return false;
    }
    
    
}
