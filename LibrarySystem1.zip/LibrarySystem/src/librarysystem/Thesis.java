package librarysystem;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Thesis implements AddForm {

    String title;
    Author author = new Author();
    String supervisingTeacher;
    int year;
    String type;
    String department;
    String university;
    int numberOfPages;
    int numberOfCopies;
    String referenceCode;

    public void AddForm() {
        Scanner sc = new Scanner(System.in);
        Scanner sc1 = new Scanner(System.in);
        System.out.println("Enter Title");
        title = sc.nextLine();
        System.out.println("Enter Author Details:");
        System.out.println("Enter Name:");
        author.name = sc.nextLine();
        System.out.println("Enter Author DOB:");
        author.dob = sc.nextLine();
        System.out.println("Enter Author NumerousBooks:");
        author.numerousBooks = sc1.nextInt();
        System.out.println("Enter Description of author's work:");
        author.description = sc.nextLine();
        sc.reset();
        System.out.println("Enter Collaborating Publishing Houses:");
        author.publishingHouses = sc.nextLine();
        System.out.println("Enter supervisingTeacher");
        supervisingTeacher = sc.nextLine();
        System.out.println("Enter Year");
        year = sc1.nextInt();
        System.out.println("Enter Type");
        type = sc.nextLine();
        System.out.println("Enter Department");
        department = sc.nextLine();
        System.out.println("Enter University");
        university = sc.nextLine();
        System.out.println("Enter Number of Pages:");
        numberOfPages = sc1.nextInt();
        System.out.println("Enter Number of Copies:");
        numberOfCopies = sc1.nextInt();
        sc.reset();
        System.out.println("Enter Reference Code:");
        referenceCode = sc.nextLine();

        try {
            File file = new File("Resource\\ThesisForm1" + ".txt");
            int increase = 1;
            //check reciept number exist before and increase one number of new reciept
            while (file.exists()) {
                increase++;
                file = new File("Resource\\ThesisForm" + increase + ".txt");
            }
            //if reciept number doesnt exist before this piece of code will be executed
            if (!file.exists()) {
                try {

                    String content = null;
                    file.createNewFile();

                    //creates new file through File writer and edit through buffered writer
                    FileWriter fw = new FileWriter(file.getAbsoluteFile());
                    BufferedWriter bw = new BufferedWriter(fw);
                    //writing to a file
                    bw.write("Title: " + title + "\nAuthor Name: " + author.name + "\nAuthor DOB: " + author.dob + "\nAuthor Numerous Books: " + author.numerousBooks
                            + "\nAuthor Work Description: " + author.description + "\nAuthor Publishing Houses: " + author.publishingHouses
                            + "\nSupervising Teacher: " + supervisingTeacher + "\nYear: " + year + "\nType: " + type + "\nDepartment: " + department
                            + "\nUniversity: " + university + "\nNumber of Pages: " + numberOfPages + "\nNumber of Copies: " + numberOfCopies
                            + "\nReference Code: " + referenceCode);

                    bw.close();

                } catch (IOException e) {
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void AddForm1(String title, String name, String dob, String numerious, String description, String publishHouse,
            String supervisor, String year, String type, String department, String university, String page, String copies, String code) {
        try {
            File file = new File("Resource\\ThesisForm1" + ".txt");
            int increase = 1;
            //check reciept number exist before and increase one number of new reciept
            while (file.exists()) {
                increase++;
                file = new File("Resource\\ThesisForm" + increase + ".txt");
            }
            //if reciept number doesnt exist before this piece of code will be executed
            if (!file.exists()) {
                try {

                    String content = null;
                    file.createNewFile();

                    //creates new file through File writer and edit through buffered writer
                    FileWriter fw = new FileWriter(file.getAbsoluteFile());
                    BufferedWriter bw = new BufferedWriter(fw);
                    //writing to a file
                    bw.write("Title: " + title + "\nAuthor Name: " + name + "\nAuthor DOB: " + dob + "\nAuthor Numerous Books: " + numerious
                            + "\nAuthor Work Description: " + description + "\nAuthor Publishing Houses: " + publishHouse
                            + "\nSupervising Teacher: " + supervisor + "\nYear: " + year + "\nType: " + type + "\nDepartment: " + department
                            + "\nUniversity: " + university + "\nNumber of Pages: " + page + "\nNumber of Copies: " + copies
                            + "\nReference Code: " + code);

                    bw.close();

                } catch (IOException e) {
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
