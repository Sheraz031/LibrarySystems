package librarysystem;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.PrinterException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.Timer;

public class Lib_Frame extends javax.swing.JFrame {

    private Connection con;
    private Statement state;
    private PreparedStatement prep;
    private ResultSet rs;
    private String query;
    private String n1, n2, n3, n4, n5;
    private int formNoBook = 0;
    private int formNoMag = 0;
    private int formNoAut = 0;
    private int formNoThesis = 0;
    private String printText = "";

    public Lib_Frame() {
        // setExtendedState(MAXIMIZED_BOTH);
        initComponents();
        setIconImage(new ImageIcon("src/library_management/textbook.png").getImage());
        setResizable(false);
        Panel();
        TextField();
        DigitalClock();
    }

    public void DigitalClock() {
        showDate();
        showTime();
    }

    public void showDate() {
        Date date = new Date();
        SimpleDateFormat s = new SimpleDateFormat("yyyy-mm-dd");
        Date.setText(s.format(date));
    }

    public void showTime() {
        new Timer(0, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Date date = new Date();
                SimpleDateFormat s = new SimpleDateFormat("hh:mm:ss a");
                Time.setText(s.format(date));
            }
        }).start();
    }

    public void TextField() {
        bb_Reset.doClick();
        tb_Reset.doClick();

    }

    public void Panel() {
        Book_Panel.setVisible(true);
        Thesis_Panel.setVisible(false);
        Megazine_Panel.setVisible(false);
        Author_Panel.setVisible(false);
        Print_Panel.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Line_LButtomLine1 = new javax.swing.JLabel();
        Line_ButtomLine2 = new javax.swing.JLabel();
        MenuPanal = new javax.swing.JPanel();
        Menu_LSelectOption = new javax.swing.JLabel();
        Menu_LLine1 = new javax.swing.JLabel();
        Menu_LLine2 = new javax.swing.JLabel();
        BookPanel = new javax.swing.JButton();
        ThesisPanel = new javax.swing.JButton();
        Megazinepanel = new javax.swing.JButton();
        AuthorPanel = new javax.swing.JButton();
        Exit = new javax.swing.JButton();
        DateAndTime_Panel = new javax.swing.JPanel();
        Date = new javax.swing.JLabel();
        Time = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        PrintPanel = new javax.swing.JButton();
        LogoPanal = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        Author_Panel = new javax.swing.JPanel();
        Issue_LBookName = new javax.swing.JLabel();
        Issue_LAutherName = new javax.swing.JLabel();
        Issue_LStudentName = new javax.swing.JLabel();
        Issue_LStudentId = new javax.swing.JLabel();
        a_Name = new javax.swing.JTextField();
        a_DOB = new javax.swing.JTextField();
        a_NumerousBooks = new javax.swing.JTextField();
        a_PublishHouse = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        a_Description = new javax.swing.JTextArea();
        a_Search = new javax.swing.JTextField();
        ab_Search = new javax.swing.JButton();
        ac_Search = new javax.swing.JComboBox<>();
        Search_LSearchBy3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        ab_Add = new javax.swing.JButton();
        ab_Modify = new javax.swing.JButton();
        ab_Reset = new javax.swing.JButton();
        Issue_LStudentName1 = new javax.swing.JLabel();
        Book_Panel = new javax.swing.JPanel();
        Add_LBookName = new javax.swing.JLabel();
        Add_LAuther = new javax.swing.JLabel();
        Add_LEddition = new javax.swing.JLabel();
        Add_LIsReserved = new javax.swing.JLabel();
        Add_LSerialNumber = new javax.swing.JLabel();
        b_Title = new javax.swing.JTextField();
        b_AuthorName = new javax.swing.JTextField();
        b_AuthorDob = new javax.swing.JTextField();
        b_copies = new javax.swing.JTextField();
        b_code = new javax.swing.JTextField();
        b_numerous = new javax.swing.JTextField();
        bb_Reset = new javax.swing.JButton();
        bb_Add = new javax.swing.JButton();
        Add_LCoppies = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        b_description = new javax.swing.JTextArea();
        b_publisher = new javax.swing.JTextField();
        Add_LCoppies1 = new javax.swing.JLabel();
        b_publishouse = new javax.swing.JTextField();
        Add_LCoppies5 = new javax.swing.JLabel();
        Add_LCoppies6 = new javax.swing.JLabel();
        b_isbn = new javax.swing.JTextField();
        Add_LBookName1 = new javax.swing.JLabel();
        Add_LAuther1 = new javax.swing.JLabel();
        b_year = new javax.swing.JTextField();
        b_pages = new javax.swing.JTextField();
        Add_LEddition1 = new javax.swing.JLabel();
        bc_Search = new javax.swing.JComboBox<>();
        bb_Search = new javax.swing.JButton();
        b_Search = new javax.swing.JTextField();
        Search_LSearchBy1 = new javax.swing.JLabel();
        bb_Modify = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        Megazine_Panel = new javax.swing.JPanel();
        Search_LSearchBy = new javax.swing.JLabel();
        mc_Combo = new javax.swing.JComboBox<>();
        m_Search = new javax.swing.JTextField();
        mb_Search = new javax.swing.JButton();
        mb_Reset = new javax.swing.JButton();
        m_Issue = new javax.swing.JTextField();
        Add_LCoppies9 = new javax.swing.JLabel();
        m_Code = new javax.swing.JTextField();
        Add_LEddition4 = new javax.swing.JLabel();
        m_Copies = new javax.swing.JTextField();
        m_Volume = new javax.swing.JTextField();
        Add_LCoppies11 = new javax.swing.JLabel();
        mb_Add = new javax.swing.JButton();
        m_Isbn = new javax.swing.JTextField();
        Add_LAuther4 = new javax.swing.JLabel();
        m_Pages = new javax.swing.JTextField();
        Add_LBookName4 = new javax.swing.JLabel();
        m_Title = new javax.swing.JTextField();
        m_Year = new javax.swing.JTextField();
        Add_LAuther5 = new javax.swing.JLabel();
        Add_LEddition5 = new javax.swing.JLabel();
        Add_LBookName5 = new javax.swing.JLabel();
        mb_Modify = new javax.swing.JButton();
        Add_LCoppies10 = new javax.swing.JLabel();
        m_Pubisher = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        Thesis_Panel = new javax.swing.JPanel();
        Add_LEddition2 = new javax.swing.JLabel();
        t_pages = new javax.swing.JTextField();
        t_Year = new javax.swing.JTextField();
        Add_LAuther2 = new javax.swing.JLabel();
        Add_LBookName2 = new javax.swing.JLabel();
        t_Supervisor = new javax.swing.JTextField();
        Add_LCoppies7 = new javax.swing.JLabel();
        Add_LCoppies8 = new javax.swing.JLabel();
        t_PublishingHouse = new javax.swing.JTextField();
        Add_LCoppies2 = new javax.swing.JLabel();
        t_Department = new javax.swing.JTextField();
        jScrollPane10 = new javax.swing.JScrollPane();
        t_Description = new javax.swing.JTextArea();
        Add_LCoppies3 = new javax.swing.JLabel();
        tb_Add = new javax.swing.JButton();
        tb_Reset = new javax.swing.JButton();
        t_Numerous = new javax.swing.JTextField();
        t_code = new javax.swing.JTextField();
        t_University = new javax.swing.JTextField();
        t_Dob = new javax.swing.JTextField();
        t_Name = new javax.swing.JTextField();
        t_Title = new javax.swing.JTextField();
        Add_LSerialNumber1 = new javax.swing.JLabel();
        Add_LIsReserved1 = new javax.swing.JLabel();
        Add_LEddition3 = new javax.swing.JLabel();
        Add_LAuther3 = new javax.swing.JLabel();
        Add_LBookName3 = new javax.swing.JLabel();
        Add_LCoppies4 = new javax.swing.JLabel();
        t_Type = new javax.swing.JTextField();
        t_Search = new javax.swing.JTextField();
        tb_Search = new javax.swing.JButton();
        tc_Combo = new javax.swing.JComboBox<>();
        Search_LSearchBy2 = new javax.swing.JLabel();
        tb_Modify = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        t_Copies = new javax.swing.JTextField();
        Add_LCoppies12 = new javax.swing.JLabel();
        Print_Panel = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        Print_TextArea = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();
        ab_Reset1 = new javax.swing.JButton();
        pc_Search = new javax.swing.JComboBox<>();
        pb_Search = new javax.swing.JButton();
        p_Search = new javax.swing.JTextField();
        Search_LSearchBy4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("LIB MANAGEMENT");
        setBackground(new java.awt.Color(255, 255, 0));
        setFont(new java.awt.Font("Segoe Script", 3, 18)); // NOI18N
        setIconImages(null);
        setPreferredSize(new java.awt.Dimension(600, 490));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Line_LButtomLine1.setForeground(new java.awt.Color(102, 102, 102));
        Line_LButtomLine1.setText("     - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  ");
        getContentPane().add(Line_LButtomLine1, new org.netbeans.lib.awtextra.AbsoluteConstraints(189, 470, 390, -1));

        Line_ButtomLine2.setForeground(new java.awt.Color(102, 102, 102));
        Line_ButtomLine2.setText("     - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -  ");
        getContentPane().add(Line_ButtomLine2, new org.netbeans.lib.awtextra.AbsoluteConstraints(189, 470, 390, 20));

        MenuPanal.setBackground(new java.awt.Color(102, 102, 102));
        MenuPanal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Menu_LSelectOption.setFont(new java.awt.Font("Segoe Script", 3, 16)); // NOI18N
        Menu_LSelectOption.setForeground(new java.awt.Color(240, 240, 240));
        Menu_LSelectOption.setText("Select Any Option");
        MenuPanal.add(Menu_LSelectOption, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 160, 30));

        Menu_LLine1.setForeground(new java.awt.Color(240, 240, 240));
        Menu_LLine1.setText("- - - - - - - - - - - - - - - - - - - - - - ");
        MenuPanal.add(Menu_LLine1, new org.netbeans.lib.awtextra.AbsoluteConstraints(14, 50, 160, -1));

        Menu_LLine2.setForeground(new java.awt.Color(240, 240, 240));
        Menu_LLine2.setText("- - - - - - - - - - - - - - -");
        MenuPanal.add(Menu_LLine2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 360, 120, -1));

        BookPanel.setText("Book");
        BookPanel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BookPanelActionPerformed(evt);
            }
        });
        MenuPanal.add(BookPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 180, -1));

        ThesisPanel.setText("Thesis");
        ThesisPanel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThesisPanelActionPerformed(evt);
            }
        });
        MenuPanal.add(ThesisPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 180, -1));

        Megazinepanel.setText("Megazine");
        Megazinepanel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MegazinepanelActionPerformed(evt);
            }
        });
        MenuPanal.add(Megazinepanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, 180, -1));

        AuthorPanel.setText("Author");
        AuthorPanel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AuthorPanelActionPerformed(evt);
            }
        });
        MenuPanal.add(AuthorPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 230, 180, -1));

        Exit.setText("Exit");
        Exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ExitActionPerformed(evt);
            }
        });
        MenuPanal.add(Exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 330, 180, -1));

        javax.swing.GroupLayout DateAndTime_PanelLayout = new javax.swing.GroupLayout(DateAndTime_Panel);
        DateAndTime_Panel.setLayout(DateAndTime_PanelLayout);
        DateAndTime_PanelLayout.setHorizontalGroup(
            DateAndTime_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        DateAndTime_PanelLayout.setVerticalGroup(
            DateAndTime_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 7, Short.MAX_VALUE)
        );

        MenuPanal.add(DateAndTime_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 482, 180, 7));

        Date.setForeground(new java.awt.Color(204, 204, 204));
        Date.setText("yyyy-mm-dd");
        MenuPanal.add(Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 410, 70, 20));

        Time.setForeground(new java.awt.Color(204, 204, 204));
        Time.setText("HH:mm:ss ap");
        MenuPanal.add(Time, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 430, -1, -1));

        jLabel9.setForeground(new java.awt.Color(204, 204, 0));
        jLabel9.setText("- - - - - - - - - - - -");
        MenuPanal.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 400, -1, -1));

        jLabel12.setForeground(new java.awt.Color(204, 204, 0));
        jLabel12.setText("- - - - - - - - - - - -");
        MenuPanal.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 440, -1, -1));

        jLabel13.setForeground(new java.awt.Color(204, 204, 0));
        jLabel13.setText("     Clock");
        MenuPanal.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 390, 60, -1));

        PrintPanel.setText("Print");
        PrintPanel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PrintPanelActionPerformed(evt);
            }
        });
        MenuPanal.add(PrintPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 180, -1));

        getContentPane().add(MenuPanal, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 180, 490));

        LogoPanal.setBackground(new java.awt.Color(102, 102, 102));
        LogoPanal.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Segoe Script", 3, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(240, 240, 240));
        jLabel2.setText("LIBRARY MANAGEMENT SYSTEM");
        LogoPanal.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, 350, 50));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 7, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 70, Short.MAX_VALUE)
        );

        LogoPanal.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 0, 7, 70));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 7, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 70, Short.MAX_VALUE)
        );

        LogoPanal.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 7, 70));

        getContentPane().add(LogoPanal, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 580, 70));

        Issue_LBookName.setText("Name");

        Issue_LAutherName.setText("Date of Birth");

        Issue_LStudentName.setText("Numerous Books");

        Issue_LStudentId.setText("Author Work's Description");

        a_Name.setBackground(new java.awt.Color(102, 102, 102));
        a_Name.setForeground(new java.awt.Color(240, 240, 240));
        a_Name.setCaretColor(new java.awt.Color(255, 255, 51));

        a_DOB.setBackground(new java.awt.Color(102, 102, 102));
        a_DOB.setForeground(new java.awt.Color(240, 240, 240));
        a_DOB.setCaretColor(new java.awt.Color(255, 255, 51));
        a_DOB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                a_DOBActionPerformed(evt);
            }
        });

        a_NumerousBooks.setBackground(new java.awt.Color(102, 102, 102));
        a_NumerousBooks.setForeground(new java.awt.Color(240, 240, 240));
        a_NumerousBooks.setCaretColor(new java.awt.Color(255, 255, 51));
        a_NumerousBooks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                a_NumerousBooksActionPerformed(evt);
            }
        });

        a_PublishHouse.setBackground(new java.awt.Color(102, 102, 102));
        a_PublishHouse.setForeground(new java.awt.Color(240, 240, 240));
        a_PublishHouse.setCaretColor(new java.awt.Color(255, 255, 51));

        a_Description.setBackground(new java.awt.Color(102, 102, 102));
        a_Description.setFont(new java.awt.Font("Segoe Script", 3, 13)); // NOI18N
        a_Description.setForeground(new java.awt.Color(240, 240, 240));
        a_Description.setText("Enter Description Here");
        jScrollPane6.setViewportView(a_Description);

        a_Search.setBackground(new java.awt.Color(102, 102, 102));
        a_Search.setForeground(new java.awt.Color(240, 240, 240));
        a_Search.setCaretColor(new java.awt.Color(255, 255, 51));
        a_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                a_SearchActionPerformed(evt);
            }
        });

        ab_Search.setText("Search");
        ab_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ab_SearchActionPerformed(evt);
            }
        });

        ac_Search.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Auther", "Author Keyword" }));
        ac_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ac_SearchActionPerformed(evt);
            }
        });

        Search_LSearchBy3.setText("Search By");

        jLabel5.setFont(new java.awt.Font("Segoe Script", 3, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 102, 102));
        jLabel5.setText("AUTHOR");

        ab_Add.setText("Add");
        ab_Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ab_AddActionPerformed(evt);
            }
        });

        ab_Modify.setText("Modify");
        ab_Modify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ab_ModifyActionPerformed(evt);
            }
        });

        ab_Reset.setText("Reset");
        ab_Reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ab_ResetActionPerformed(evt);
            }
        });

        Issue_LStudentName1.setText("Publish House");

        javax.swing.GroupLayout Author_PanelLayout = new javax.swing.GroupLayout(Author_Panel);
        Author_Panel.setLayout(Author_PanelLayout);
        Author_PanelLayout.setHorizontalGroup(
            Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Author_PanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Author_PanelLayout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(218, 218, 218))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Author_PanelLayout.createSequentialGroup()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(106, 106, 106))))
            .addGroup(Author_PanelLayout.createSequentialGroup()
                .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Author_PanelLayout.createSequentialGroup()
                        .addGap(77, 77, 77)
                        .addComponent(Search_LSearchBy3)
                        .addGap(18, 18, 18)
                        .addComponent(a_Search, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(ab_Search)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(ac_Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Author_PanelLayout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Issue_LStudentId)
                            .addGroup(Author_PanelLayout.createSequentialGroup()
                                .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Issue_LAutherName)
                                    .addComponent(Issue_LBookName))
                                .addGap(18, 18, 18)
                                .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(a_DOB, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                                    .addComponent(a_Name))
                                .addGap(51, 51, 51)
                                .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Issue_LStudentName)
                                    .addComponent(Issue_LStudentName1))
                                .addGap(27, 27, 27)
                                .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(a_PublishHouse)
                                    .addComponent(a_NumerousBooks))))))
                .addGap(102, 102, 102))
            .addGroup(Author_PanelLayout.createSequentialGroup()
                .addGap(138, 138, 138)
                .addComponent(ab_Add, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(ab_Modify, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ab_Reset, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        Author_PanelLayout.setVerticalGroup(
            Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Author_PanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Search_LSearchBy3)
                    .addComponent(a_Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ab_Search)
                    .addComponent(ac_Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Author_PanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
                        .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(a_DOB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Issue_LAutherName)
                            .addComponent(Issue_LStudentName1)
                            .addComponent(a_PublishHouse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33)
                        .addComponent(Issue_LStudentId)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39))
                    .addGroup(Author_PanelLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Issue_LBookName)
                            .addComponent(a_Name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Issue_LStudentName)
                            .addComponent(a_NumerousBooks, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ab_Add)
                    .addGroup(Author_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ab_Reset)
                        .addComponent(ab_Modify)))
                .addGap(40, 40, 40))
        );

        getContentPane().add(Author_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 570, 410));

        Book_Panel.setPreferredSize(new java.awt.Dimension(7, 20));

        Add_LBookName.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LBookName.setForeground(new java.awt.Color(102, 102, 102));
        Add_LBookName.setText("Book Title");

        Add_LAuther.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LAuther.setForeground(new java.awt.Color(102, 102, 102));
        Add_LAuther.setText("Author Name");

        Add_LEddition.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LEddition.setForeground(new java.awt.Color(102, 102, 102));
        Add_LEddition.setText("Author Dob");

        Add_LIsReserved.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LIsReserved.setForeground(new java.awt.Color(102, 102, 102));
        Add_LIsReserved.setText("Author Numerous ");

        Add_LSerialNumber.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LSerialNumber.setForeground(new java.awt.Color(102, 102, 102));
        Add_LSerialNumber.setText("Author Description");

        b_Title.setBackground(new java.awt.Color(102, 102, 102));
        b_Title.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        b_Title.setForeground(new java.awt.Color(240, 240, 240));
        b_Title.setCaretColor(new java.awt.Color(255, 255, 0));
        b_Title.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        b_AuthorName.setBackground(new java.awt.Color(102, 102, 102));
        b_AuthorName.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        b_AuthorName.setForeground(new java.awt.Color(240, 240, 240));
        b_AuthorName.setCaretColor(new java.awt.Color(255, 255, 0));

        b_AuthorDob.setBackground(new java.awt.Color(102, 102, 102));
        b_AuthorDob.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        b_AuthorDob.setForeground(new java.awt.Color(240, 240, 240));
        b_AuthorDob.setCaretColor(new java.awt.Color(255, 255, 0));

        b_copies.setBackground(new java.awt.Color(102, 102, 102));
        b_copies.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        b_copies.setForeground(new java.awt.Color(240, 240, 240));
        b_copies.setCaretColor(new java.awt.Color(255, 255, 0));
        b_copies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_copiesActionPerformed(evt);
            }
        });

        b_code.setBackground(new java.awt.Color(102, 102, 102));
        b_code.setForeground(new java.awt.Color(240, 240, 240));
        b_code.setCaretColor(new java.awt.Color(255, 255, 0));

        b_numerous.setBackground(new java.awt.Color(102, 102, 102));
        b_numerous.setForeground(new java.awt.Color(240, 240, 240));
        b_numerous.setCaretColor(new java.awt.Color(255, 255, 0));
        b_numerous.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_numerousActionPerformed(evt);
            }
        });

        bb_Reset.setText("Reset");
        bb_Reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bb_ResetActionPerformed(evt);
            }
        });

        bb_Add.setText("Add");
        bb_Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bb_AddActionPerformed(evt);
            }
        });

        Add_LCoppies.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies.setText("Publishing house");

        b_description.setBackground(new java.awt.Color(102, 102, 102));
        b_description.setFont(new java.awt.Font("Segoe Script", 3, 13)); // NOI18N
        b_description.setForeground(new java.awt.Color(240, 240, 240));
        b_description.setText("Author Description");
        b_description.setCaretColor(new java.awt.Color(255, 255, 0));
        jScrollPane9.setViewportView(b_description);

        b_publisher.setBackground(new java.awt.Color(102, 102, 102));
        b_publisher.setForeground(new java.awt.Color(240, 240, 240));
        b_publisher.setCaretColor(new java.awt.Color(255, 255, 0));
        b_publisher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_publisherActionPerformed(evt);
            }
        });

        Add_LCoppies1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies1.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies1.setText("Publisher");

        b_publishouse.setBackground(new java.awt.Color(102, 102, 102));
        b_publishouse.setForeground(new java.awt.Color(240, 240, 240));
        b_publishouse.setCaretColor(new java.awt.Color(255, 255, 0));
        b_publishouse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_publishouseActionPerformed(evt);
            }
        });

        Add_LCoppies5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies5.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies5.setText("Copies");

        Add_LCoppies6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies6.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies6.setText("References Code");

        b_isbn.setBackground(new java.awt.Color(102, 102, 102));
        b_isbn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        b_isbn.setForeground(new java.awt.Color(240, 240, 240));
        b_isbn.setCaretColor(new java.awt.Color(255, 255, 0));
        b_isbn.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        Add_LBookName1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LBookName1.setForeground(new java.awt.Color(102, 102, 102));
        Add_LBookName1.setText("ISBN");

        Add_LAuther1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LAuther1.setForeground(new java.awt.Color(102, 102, 102));
        Add_LAuther1.setText("Year");

        b_year.setBackground(new java.awt.Color(102, 102, 102));
        b_year.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        b_year.setForeground(new java.awt.Color(240, 240, 240));
        b_year.setCaretColor(new java.awt.Color(255, 255, 0));

        b_pages.setBackground(new java.awt.Color(102, 102, 102));
        b_pages.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        b_pages.setForeground(new java.awt.Color(240, 240, 240));
        b_pages.setCaretColor(new java.awt.Color(255, 255, 0));

        Add_LEddition1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LEddition1.setForeground(new java.awt.Color(102, 102, 102));
        Add_LEddition1.setText("No of Pages");

        bc_Search.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tiltle", "Book Auther", "Keyword title" }));
        bc_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bc_SearchActionPerformed(evt);
            }
        });

        bb_Search.setText("Search");
        bb_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bb_SearchActionPerformed(evt);
            }
        });

        b_Search.setBackground(new java.awt.Color(102, 102, 102));
        b_Search.setForeground(new java.awt.Color(240, 240, 240));
        b_Search.setCaretColor(new java.awt.Color(255, 255, 51));
        b_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_SearchActionPerformed(evt);
            }
        });

        Search_LSearchBy1.setText("Search By");

        bb_Modify.setText("Modify");
        bb_Modify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bb_ModifyActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe Script", 3, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 102, 102));
        jLabel3.setText("BOOK");

        javax.swing.GroupLayout Book_PanelLayout = new javax.swing.GroupLayout(Book_Panel);
        Book_Panel.setLayout(Book_PanelLayout);
        Book_PanelLayout.setHorizontalGroup(
            Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Book_PanelLayout.createSequentialGroup()
                .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Book_PanelLayout.createSequentialGroup()
                        .addGap(248, 248, 248)
                        .addComponent(jLabel3))
                    .addGroup(Book_PanelLayout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Book_PanelLayout.createSequentialGroup()
                                .addComponent(Add_LCoppies1)
                                .addGap(206, 206, 206)
                                .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Book_PanelLayout.createSequentialGroup()
                                        .addGap(10, 10, 10)
                                        .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(Add_LBookName1)
                                            .addComponent(Add_LAuther1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(Add_LEddition1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(b_pages, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b_year, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b_isbn, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Book_PanelLayout.createSequentialGroup()
                                        .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(Book_PanelLayout.createSequentialGroup()
                                                .addGap(2, 2, 2)
                                                .addComponent(Add_LCoppies6)
                                                .addGap(18, 18, 18))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Book_PanelLayout.createSequentialGroup()
                                                .addComponent(Add_LIsReserved)
                                                .addGap(13, 13, 13)))
                                        .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(b_numerous, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(b_code, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(Book_PanelLayout.createSequentialGroup()
                                    .addComponent(Add_LCoppies, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(b_publishouse, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Book_PanelLayout.createSequentialGroup()
                                    .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(Add_LBookName)
                                            .addComponent(Add_LAuther, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(Add_LEddition, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(Add_LCoppies5))
                                    .addGap(28, 28, 28)
                                    .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(b_publisher)
                                        .addComponent(b_Title)
                                        .addComponent(b_AuthorName)
                                        .addComponent(b_AuthorDob)
                                        .addComponent(b_copies, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(Book_PanelLayout.createSequentialGroup()
                                .addComponent(Add_LSerialNumber)
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Book_PanelLayout.createSequentialGroup()
                                .addGap(43, 43, 43)
                                .addComponent(Search_LSearchBy1)
                                .addGap(18, 18, 18)
                                .addComponent(b_Search, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(bb_Search)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(bc_Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Book_PanelLayout.createSequentialGroup()
                                .addGap(105, 105, 105)
                                .addComponent(bb_Add, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(25, 25, 25)
                                .addComponent(bb_Modify, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(bb_Reset, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(114, Short.MAX_VALUE))
        );
        Book_PanelLayout.setVerticalGroup(
            Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Book_PanelLayout.createSequentialGroup()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Search_LSearchBy1)
                    .addComponent(b_Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bb_Search)
                    .addComponent(bc_Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Book_PanelLayout.createSequentialGroup()
                        .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Add_LBookName)
                            .addComponent(b_Title, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Add_LAuther)
                            .addComponent(b_AuthorName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(b_AuthorDob, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Add_LEddition, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Book_PanelLayout.createSequentialGroup()
                        .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Add_LBookName1)
                            .addComponent(b_isbn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Add_LAuther1)
                            .addComponent(b_year, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(b_pages, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Add_LEddition1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(16, 16, 16)
                .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Add_LCoppies5)
                    .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(b_copies, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Add_LCoppies6)
                        .addComponent(b_code, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Add_LIsReserved)
                        .addComponent(Add_LCoppies1)
                        .addComponent(b_publisher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(b_numerous, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Add_LCoppies)
                    .addComponent(b_publishouse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Add_LSerialNumber)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bb_Add)
                    .addGroup(Book_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(bb_Reset)
                        .addComponent(bb_Modify)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(Book_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 570, 400));

        Search_LSearchBy.setText("Search By");

        mc_Combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Title", "Publisher", "Publisher Keyword" }));
        mc_Combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mc_ComboActionPerformed(evt);
            }
        });

        m_Search.setBackground(new java.awt.Color(102, 102, 102));
        m_Search.setForeground(new java.awt.Color(240, 240, 240));
        m_Search.setCaretColor(new java.awt.Color(255, 255, 51));
        m_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                m_SearchActionPerformed(evt);
            }
        });

        mb_Search.setText("Search");
        mb_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mb_SearchActionPerformed(evt);
            }
        });

        mb_Reset.setText("Reset");
        mb_Reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mb_ResetActionPerformed(evt);
            }
        });

        m_Issue.setBackground(new java.awt.Color(102, 102, 102));
        m_Issue.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        m_Issue.setForeground(new java.awt.Color(240, 240, 240));
        m_Issue.setCaretColor(new java.awt.Color(255, 255, 0));

        Add_LCoppies9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies9.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies9.setText("Isbn");

        m_Code.setBackground(new java.awt.Color(102, 102, 102));
        m_Code.setForeground(new java.awt.Color(240, 240, 240));
        m_Code.setCaretColor(new java.awt.Color(255, 255, 0));

        Add_LEddition4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LEddition4.setForeground(new java.awt.Color(102, 102, 102));
        Add_LEddition4.setText("No of Pages");

        m_Copies.setBackground(new java.awt.Color(102, 102, 102));
        m_Copies.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        m_Copies.setForeground(new java.awt.Color(240, 240, 240));
        m_Copies.setCaretColor(new java.awt.Color(255, 255, 0));

        m_Volume.setBackground(new java.awt.Color(102, 102, 102));
        m_Volume.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        m_Volume.setForeground(new java.awt.Color(240, 240, 240));
        m_Volume.setCaretColor(new java.awt.Color(255, 255, 0));
        m_Volume.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        Add_LCoppies11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies11.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies11.setText("References Code");

        mb_Add.setText("Add");
        mb_Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mb_AddActionPerformed(evt);
            }
        });

        m_Isbn.setBackground(new java.awt.Color(102, 102, 102));
        m_Isbn.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        m_Isbn.setForeground(new java.awt.Color(240, 240, 240));
        m_Isbn.setCaretColor(new java.awt.Color(255, 255, 0));
        m_Isbn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                m_IsbnActionPerformed(evt);
            }
        });

        Add_LAuther4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LAuther4.setForeground(new java.awt.Color(102, 102, 102));
        Add_LAuther4.setText("Year");

        m_Pages.setBackground(new java.awt.Color(102, 102, 102));
        m_Pages.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        m_Pages.setForeground(new java.awt.Color(240, 240, 240));
        m_Pages.setCaretColor(new java.awt.Color(255, 255, 0));

        Add_LBookName4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LBookName4.setForeground(new java.awt.Color(102, 102, 102));
        Add_LBookName4.setText("Volume");

        m_Title.setBackground(new java.awt.Color(102, 102, 102));
        m_Title.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        m_Title.setForeground(new java.awt.Color(240, 240, 240));
        m_Title.setCaretColor(new java.awt.Color(255, 255, 0));
        m_Title.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        m_Year.setBackground(new java.awt.Color(102, 102, 102));
        m_Year.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        m_Year.setForeground(new java.awt.Color(240, 240, 240));
        m_Year.setCaretColor(new java.awt.Color(255, 255, 0));

        Add_LAuther5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LAuther5.setForeground(new java.awt.Color(102, 102, 102));
        Add_LAuther5.setText("Issue");

        Add_LEddition5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LEddition5.setForeground(new java.awt.Color(102, 102, 102));
        Add_LEddition5.setText("Copies");

        Add_LBookName5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LBookName5.setForeground(new java.awt.Color(102, 102, 102));
        Add_LBookName5.setText("Megazine Title");

        mb_Modify.setText("Modify");
        mb_Modify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mb_ModifyActionPerformed(evt);
            }
        });

        Add_LCoppies10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies10.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies10.setText("Publisher");

        m_Pubisher.setBackground(new java.awt.Color(102, 102, 102));
        m_Pubisher.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        m_Pubisher.setForeground(new java.awt.Color(240, 240, 240));
        m_Pubisher.setCaretColor(new java.awt.Color(255, 255, 0));
        m_Pubisher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                m_PubisherActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe Script", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 102, 102));
        jLabel1.setText("MEGAZINE");

        javax.swing.GroupLayout Megazine_PanelLayout = new javax.swing.GroupLayout(Megazine_Panel);
        Megazine_Panel.setLayout(Megazine_PanelLayout);
        Megazine_PanelLayout.setHorizontalGroup(
            Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Megazine_PanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Search_LSearchBy)
                .addGap(18, 18, 18)
                .addComponent(m_Search, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(mb_Search)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(mc_Combo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(69, 69, 69))
            .addGroup(Megazine_PanelLayout.createSequentialGroup()
                .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Megazine_PanelLayout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Megazine_PanelLayout.createSequentialGroup()
                                .addGap(64, 64, 64)
                                .addComponent(mb_Add, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(35, 35, 35)
                                .addComponent(mb_Modify, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(mb_Reset, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Megazine_PanelLayout.createSequentialGroup()
                                .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Add_LBookName5)
                                    .addComponent(Add_LAuther5, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Add_LEddition5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Add_LCoppies9)
                                    .addComponent(Add_LCoppies10))
                                .addGap(28, 28, 28)
                                .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(m_Title)
                                    .addComponent(m_Issue)
                                    .addComponent(m_Copies)
                                    .addComponent(m_Isbn, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(m_Pubisher, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(68, 68, 68)
                                .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(Megazine_PanelLayout.createSequentialGroup()
                                        .addGap(8, 8, 8)
                                        .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(Add_LBookName4)
                                            .addComponent(Add_LAuther4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(Add_LEddition4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(m_Pages, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(m_Year, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(m_Volume, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(Megazine_PanelLayout.createSequentialGroup()
                                        .addComponent(Add_LCoppies11)
                                        .addGap(18, 18, 18)
                                        .addComponent(m_Code, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(Megazine_PanelLayout.createSequentialGroup()
                        .addGap(219, 219, 219)
                        .addComponent(jLabel1)))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        Megazine_PanelLayout.setVerticalGroup(
            Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Megazine_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Search_LSearchBy)
                    .addComponent(m_Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mb_Search)
                    .addComponent(mc_Combo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Megazine_PanelLayout.createSequentialGroup()
                        .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Add_LBookName5)
                            .addComponent(m_Title, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Add_LAuther5)
                            .addComponent(m_Issue, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(m_Copies, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Add_LEddition5, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Megazine_PanelLayout.createSequentialGroup()
                        .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Add_LBookName4)
                            .addComponent(m_Volume, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Add_LAuther4)
                            .addComponent(m_Year, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(m_Pages, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Add_LEddition4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(16, 16, 16)
                .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Add_LCoppies9)
                    .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(m_Isbn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Add_LCoppies11)
                        .addComponent(m_Code, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(16, 16, 16)
                .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Add_LCoppies10)
                    .addComponent(m_Pubisher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(Megazine_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mb_Reset)
                    .addComponent(mb_Modify)
                    .addComponent(mb_Add))
                .addGap(67, 67, 67))
        );

        getContentPane().add(Megazine_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 70, 560, 410));

        Add_LEddition2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LEddition2.setForeground(new java.awt.Color(102, 102, 102));
        Add_LEddition2.setText("No of Pages");

        t_pages.setBackground(new java.awt.Color(102, 102, 102));
        t_pages.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        t_pages.setForeground(new java.awt.Color(240, 240, 240));
        t_pages.setCaretColor(new java.awt.Color(255, 255, 0));

        t_Year.setBackground(new java.awt.Color(102, 102, 102));
        t_Year.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        t_Year.setForeground(new java.awt.Color(240, 240, 240));
        t_Year.setCaretColor(new java.awt.Color(255, 255, 0));

        Add_LAuther2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LAuther2.setForeground(new java.awt.Color(102, 102, 102));
        Add_LAuther2.setText("Year");

        Add_LBookName2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LBookName2.setForeground(new java.awt.Color(102, 102, 102));
        Add_LBookName2.setText("Supervisor");

        t_Supervisor.setBackground(new java.awt.Color(102, 102, 102));
        t_Supervisor.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        t_Supervisor.setForeground(new java.awt.Color(240, 240, 240));
        t_Supervisor.setCaretColor(new java.awt.Color(255, 255, 0));
        t_Supervisor.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        Add_LCoppies7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies7.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies7.setText("References Code");

        Add_LCoppies8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies8.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies8.setText("University");

        t_PublishingHouse.setBackground(new java.awt.Color(102, 102, 102));
        t_PublishingHouse.setForeground(new java.awt.Color(240, 240, 240));
        t_PublishingHouse.setCaretColor(new java.awt.Color(255, 255, 0));
        t_PublishingHouse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_PublishingHouseActionPerformed(evt);
            }
        });

        Add_LCoppies2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies2.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies2.setText("Department");

        t_Department.setBackground(new java.awt.Color(102, 102, 102));
        t_Department.setForeground(new java.awt.Color(240, 240, 240));
        t_Department.setCaretColor(new java.awt.Color(255, 255, 0));
        t_Department.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_DepartmentActionPerformed(evt);
            }
        });

        t_Description.setBackground(new java.awt.Color(102, 102, 102));
        t_Description.setFont(new java.awt.Font("Segoe Script", 3, 13)); // NOI18N
        t_Description.setForeground(new java.awt.Color(240, 240, 240));
        t_Description.setText("Author Description");
        t_Description.setCaretColor(new java.awt.Color(255, 255, 0));
        jScrollPane10.setViewportView(t_Description);

        Add_LCoppies3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies3.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies3.setText("Publishing house");

        tb_Add.setText("Add");
        tb_Add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tb_AddActionPerformed(evt);
            }
        });

        tb_Reset.setText("Reset");
        tb_Reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tb_ResetActionPerformed(evt);
            }
        });

        t_Numerous.setBackground(new java.awt.Color(102, 102, 102));
        t_Numerous.setForeground(new java.awt.Color(240, 240, 240));
        t_Numerous.setCaretColor(new java.awt.Color(255, 255, 0));
        t_Numerous.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_NumerousActionPerformed(evt);
            }
        });

        t_code.setBackground(new java.awt.Color(102, 102, 102));
        t_code.setForeground(new java.awt.Color(240, 240, 240));
        t_code.setCaretColor(new java.awt.Color(255, 255, 0));

        t_University.setBackground(new java.awt.Color(102, 102, 102));
        t_University.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        t_University.setForeground(new java.awt.Color(240, 240, 240));
        t_University.setCaretColor(new java.awt.Color(255, 255, 0));
        t_University.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_UniversityActionPerformed(evt);
            }
        });

        t_Dob.setBackground(new java.awt.Color(102, 102, 102));
        t_Dob.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        t_Dob.setForeground(new java.awt.Color(240, 240, 240));
        t_Dob.setCaretColor(new java.awt.Color(255, 255, 0));

        t_Name.setBackground(new java.awt.Color(102, 102, 102));
        t_Name.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        t_Name.setForeground(new java.awt.Color(240, 240, 240));
        t_Name.setCaretColor(new java.awt.Color(255, 255, 0));

        t_Title.setBackground(new java.awt.Color(102, 102, 102));
        t_Title.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        t_Title.setForeground(new java.awt.Color(240, 240, 240));
        t_Title.setCaretColor(new java.awt.Color(255, 255, 0));
        t_Title.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        Add_LSerialNumber1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LSerialNumber1.setForeground(new java.awt.Color(102, 102, 102));
        Add_LSerialNumber1.setText("Author Description");

        Add_LIsReserved1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LIsReserved1.setForeground(new java.awt.Color(102, 102, 102));
        Add_LIsReserved1.setText("Author Numerous ");

        Add_LEddition3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LEddition3.setForeground(new java.awt.Color(102, 102, 102));
        Add_LEddition3.setText("Author Dob");

        Add_LAuther3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LAuther3.setForeground(new java.awt.Color(102, 102, 102));
        Add_LAuther3.setText("Author Name");

        Add_LBookName3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LBookName3.setForeground(new java.awt.Color(102, 102, 102));
        Add_LBookName3.setText("Thesis Title");

        Add_LCoppies4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies4.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies4.setText("Type");

        t_Type.setBackground(new java.awt.Color(102, 102, 102));
        t_Type.setForeground(new java.awt.Color(240, 240, 240));
        t_Type.setCaretColor(new java.awt.Color(255, 255, 0));
        t_Type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_TypeActionPerformed(evt);
            }
        });

        t_Search.setBackground(new java.awt.Color(102, 102, 102));
        t_Search.setForeground(new java.awt.Color(240, 240, 240));
        t_Search.setCaretColor(new java.awt.Color(255, 255, 51));
        t_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_SearchActionPerformed(evt);
            }
        });

        tb_Search.setText("Search");
        tb_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tb_SearchActionPerformed(evt);
            }
        });

        tc_Combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Title", "Auther", "Author Keyword" }));
        tc_Combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tc_ComboActionPerformed(evt);
            }
        });

        Search_LSearchBy2.setText("Search By");

        tb_Modify.setText("Modify");
        tb_Modify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tb_ModifyActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe Script", 3, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 102, 102));
        jLabel4.setText("THESIS");

        t_Copies.setBackground(new java.awt.Color(102, 102, 102));
        t_Copies.setForeground(new java.awt.Color(240, 240, 240));
        t_Copies.setCaretColor(new java.awt.Color(255, 255, 0));
        t_Copies.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                t_CopiesActionPerformed(evt);
            }
        });

        Add_LCoppies12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Add_LCoppies12.setForeground(new java.awt.Color(102, 102, 102));
        Add_LCoppies12.setText("Copies");

        javax.swing.GroupLayout Thesis_PanelLayout = new javax.swing.GroupLayout(Thesis_Panel);
        Thesis_Panel.setLayout(Thesis_PanelLayout);
        Thesis_PanelLayout.setHorizontalGroup(
            Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Thesis_PanelLayout.createSequentialGroup()
                .addGap(233, 233, 233)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(Thesis_PanelLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Thesis_PanelLayout.createSequentialGroup()
                        .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Thesis_PanelLayout.createSequentialGroup()
                                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Add_LCoppies2)
                                    .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(Thesis_PanelLayout.createSequentialGroup()
                                            .addComponent(Add_LCoppies3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(t_PublishingHouse, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Thesis_PanelLayout.createSequentialGroup()
                                            .addComponent(Add_LCoppies8)
                                            .addGap(44, 44, 44)
                                            .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(t_Department)
                                                .addComponent(t_University, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(Thesis_PanelLayout.createSequentialGroup()
                                            .addComponent(Add_LCoppies12, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addComponent(t_Copies, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(66, 66, 66)
                                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(Thesis_PanelLayout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(Add_LEddition2, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Add_LCoppies7)
                                            .addComponent(Add_LAuther2, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Add_LBookName2, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Thesis_PanelLayout.createSequentialGroup()
                                        .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(Add_LCoppies4, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(Add_LIsReserved1))
                                        .addGap(13, 13, 13)))
                                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(t_Numerous, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t_code, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(t_Type, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(Thesis_PanelLayout.createSequentialGroup()
                                        .addComponent(Add_LAuther3, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(28, 28, 28)
                                        .addComponent(t_Name, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(181, 181, 181)
                                        .addComponent(t_Year, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Thesis_PanelLayout.createSequentialGroup()
                                        .addComponent(Add_LBookName3)
                                        .addGap(38, 38, 38)
                                        .addComponent(t_Title, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(181, 181, 181)
                                        .addComponent(t_Supervisor, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(Thesis_PanelLayout.createSequentialGroup()
                                    .addGap(42, 42, 42)
                                    .addComponent(Search_LSearchBy2)
                                    .addGap(18, 18, 18)
                                    .addComponent(t_Search, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(tb_Search)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(tc_Combo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(t_pages, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(69, Short.MAX_VALUE))
                    .addGroup(Thesis_PanelLayout.createSequentialGroup()
                        .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Thesis_PanelLayout.createSequentialGroup()
                                .addComponent(Add_LSerialNumber1)
                                .addGap(18, 18, 18)
                                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(Thesis_PanelLayout.createSequentialGroup()
                                        .addComponent(tb_Add, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(9, 9, 9)
                                        .addComponent(tb_Modify, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(tb_Reset, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(Thesis_PanelLayout.createSequentialGroup()
                                .addComponent(Add_LEddition3, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(28, 28, 28)
                                .addComponent(t_Dob, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        Thesis_PanelLayout.setVerticalGroup(
            Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Thesis_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Search_LSearchBy2)
                    .addComponent(t_Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tb_Search)
                    .addComponent(tc_Combo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Add_LBookName3)
                        .addComponent(t_Title, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Add_LBookName2)
                        .addComponent(t_Supervisor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Add_LAuther3)
                        .addComponent(t_Name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(t_Year, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Add_LAuther2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(t_Dob, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Add_LEddition3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(t_pages, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Add_LEddition2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Add_LCoppies8)
                    .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(t_University, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(Add_LCoppies7)
                        .addComponent(t_code, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Add_LIsReserved1)
                        .addComponent(Add_LCoppies2)
                        .addComponent(t_Department, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(t_Numerous, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Thesis_PanelLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Add_LCoppies3)
                            .addComponent(t_PublishingHouse, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(10, 10, 10)
                        .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Add_LCoppies12)
                            .addComponent(t_Copies, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(Thesis_PanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Add_LCoppies4)
                            .addComponent(t_Type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Add_LSerialNumber1)
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tb_Reset)
                    .addGroup(Thesis_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(tb_Add)
                        .addComponent(tb_Modify)))
                .addContainerGap(42, Short.MAX_VALUE))
        );

        getContentPane().add(Thesis_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 570, 420));

        Print_TextArea.setEditable(false);
        Print_TextArea.setBackground(new java.awt.Color(102, 102, 102));
        Print_TextArea.setFont(new java.awt.Font("Segoe Script", 3, 24)); // NOI18N
        jScrollPane7.setViewportView(Print_TextArea);

        jLabel6.setFont(new java.awt.Font("Segoe Script", 3, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 102, 102));
        jLabel6.setText("PRINT");

        ab_Reset1.setText("Print");
        ab_Reset1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ab_Reset1ActionPerformed(evt);
            }
        });

        pc_Search.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Book Search", "Megazine Search", "Thesis Search", "Author Search" }));
        pc_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pc_SearchActionPerformed(evt);
            }
        });

        pb_Search.setText("Search");
        pb_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pb_SearchActionPerformed(evt);
            }
        });

        p_Search.setBackground(new java.awt.Color(102, 102, 102));
        p_Search.setForeground(new java.awt.Color(240, 240, 240));
        p_Search.setCaretColor(new java.awt.Color(255, 255, 51));
        p_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p_SearchActionPerformed(evt);
            }
        });

        Search_LSearchBy4.setText("Search By");

        javax.swing.GroupLayout Print_PanelLayout = new javax.swing.GroupLayout(Print_Panel);
        Print_Panel.setLayout(Print_PanelLayout);
        Print_PanelLayout.setHorizontalGroup(
            Print_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Print_PanelLayout.createSequentialGroup()
                .addGroup(Print_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Print_PanelLayout.createSequentialGroup()
                        .addGap(241, 241, 241)
                        .addComponent(ab_Reset1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Print_PanelLayout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 462, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(57, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Print_PanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(Print_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Print_PanelLayout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(233, 233, 233))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Print_PanelLayout.createSequentialGroup()
                        .addComponent(Search_LSearchBy4)
                        .addGap(18, 18, 18)
                        .addComponent(p_Search, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(pb_Search)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(pc_Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(79, 79, 79))))
        );
        Print_PanelLayout.setVerticalGroup(
            Print_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Print_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(21, 21, 21)
                .addGroup(Print_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Search_LSearchBy4)
                    .addComponent(p_Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pb_Search)
                    .addComponent(pc_Search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ab_Reset1)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        getContentPane().add(Print_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 570, 410));

        setSize(new java.awt.Dimension(772, 518));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void AuthorPanelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AuthorPanelActionPerformed
        Book_Panel.setVisible(false);
        Thesis_Panel.setVisible(false);
        Megazine_Panel.setVisible(false);
        Print_Panel.setVisible(false);
        Author_Panel.setVisible(true);

    }//GEN-LAST:event_AuthorPanelActionPerformed

    private void BookPanelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BookPanelActionPerformed
        Book_Panel.setVisible(true);
        Thesis_Panel.setVisible(false);
        Megazine_Panel.setVisible(false);
        Author_Panel.setVisible(false);
        Print_Panel.setVisible(false);


    }//GEN-LAST:event_BookPanelActionPerformed

    private void ThesisPanelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThesisPanelActionPerformed

        Book_Panel.setVisible(false);
        Thesis_Panel.setVisible(true);
        Megazine_Panel.setVisible(false);
        Author_Panel.setVisible(false);
        Print_Panel.setVisible(false);
    }//GEN-LAST:event_ThesisPanelActionPerformed

    private void MegazinepanelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MegazinepanelActionPerformed
        Book_Panel.setVisible(false);
        Thesis_Panel.setVisible(false);
        Megazine_Panel.setVisible(true);
        Author_Panel.setVisible(false);
        Print_Panel.setVisible(false);

    }//GEN-LAST:event_MegazinepanelActionPerformed

    private void ExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ExitActionPerformed
        if (JOptionPane.showConfirmDialog(null, "Are You Really Want To Exit") == 0)
            System.exit(0);
    }//GEN-LAST:event_ExitActionPerformed

    private void bb_AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bb_AddActionPerformed

        if (!b_Title.getText().isEmpty()
                && !b_AuthorName.getText().isEmpty()
                && !b_AuthorDob.getText().isEmpty()
                && !b_numerous.getText().isEmpty() && !b_description.getText().isEmpty()
                && !b_publishouse.getText().isEmpty() && !b_publisher.getText().isEmpty()
                && !b_year.getText().isEmpty() && !b_isbn.getText().isEmpty()
                && !b_pages.getText().isEmpty() && !b_copies.getText().isEmpty() && !b_code.getText().isEmpty()) {
            Book book = new Book();
            book.AddForm1(b_Title.getText(), b_AuthorName.getText(), b_AuthorDob.getText(),
                    b_numerous.getText(), b_description.getText(), b_publishouse.getText(),
                    b_publisher.getText(), b_year.getText(), b_isbn.getText(), b_pages.getText(), b_copies.getText(),
                    b_code.getText());

            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Book Added or Modified Successfully");
            bb_Reset.doClick();
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "you entered something incorrect");
        }
    }//GEN-LAST:event_bb_AddActionPerformed

    private void bb_ResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bb_ResetActionPerformed
        BookReset();
    }//GEN-LAST:event_bb_ResetActionPerformed
    private void BookReset() {
        b_Search.setText("");
        b_AuthorName.setText("");
        b_AuthorDob.setText("");
        b_Title.setText("");
        b_code.setText("");
        b_copies.setText("");
        b_description.setText("");
        b_isbn.setText("");
        b_numerous.setText("");
        b_pages.setText("");
        b_publisher.setText("");
        b_publishouse.setText("");
        b_year.setText("");
    }
    private void b_numerousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_numerousActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_b_numerousActionPerformed

    private void b_publisherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_publisherActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_b_publisherActionPerformed

    private void b_publishouseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_publishouseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_b_publishouseActionPerformed

    private void b_copiesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_copiesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_b_copiesActionPerformed

    private void t_PublishingHouseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_PublishingHouseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t_PublishingHouseActionPerformed

    private void t_DepartmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_DepartmentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t_DepartmentActionPerformed

    private void tb_AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tb_AddActionPerformed

        if (!t_Copies.getText().isEmpty() && !t_Department.getText().isEmpty() && !t_Description.getText().isEmpty() && !t_Dob.getText().isEmpty()
                && !t_Name.getText().isEmpty() && !t_PublishingHouse.getText().isEmpty() && !t_Numerous.getText().isEmpty() && !t_Supervisor.getText().isEmpty()
                && !t_Title.getText().isEmpty() && !t_Type.getText().isEmpty() && !t_University.getText().isEmpty() && !t_Year.getText().isEmpty()
                && !t_pages.getText().isEmpty() && !t_code.getText().isEmpty()) {
            new Thesis().AddForm1(t_Title.getText(),
                    t_Name.getText(),
                    t_Dob.getText(),
                    t_Numerous.getText(),
                    t_Description.getText(),
                    t_PublishingHouse.getText(),
                    t_Supervisor.getText(),
                    t_Year.getText(),
                    t_Type.getText(),
                    t_Department.getText(), t_University.getText(), t_pages.getText(), t_Copies.getText(), t_code.getText());
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Thesis Form Added or Modified");
            tb_Reset.doClick();
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Incorrect Fields");
        }


    }//GEN-LAST:event_tb_AddActionPerformed

    private void tb_ResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tb_ResetActionPerformed
        t_Department.setText("");
        t_Description.setText("");
        t_Dob.setText("");
        t_Name.setText("");
        t_Numerous.setText("");
        t_PublishingHouse.setText("");
        t_Supervisor.setText("");
        t_Title.setText("");
        t_Type.setText("");
        t_University.setText("");
        t_Year.setText("");
        t_code.setText("");
        t_pages.setText("");
        t_Copies.setText("");
        t_Search.setText("");
    }//GEN-LAST:event_tb_ResetActionPerformed

    private void t_NumerousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_NumerousActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t_NumerousActionPerformed

    private void t_UniversityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_UniversityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t_UniversityActionPerformed

    private void t_TypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_TypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t_TypeActionPerformed

    private void m_IsbnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_m_IsbnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_m_IsbnActionPerformed

    private void mb_AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mb_AddActionPerformed

        if (!m_Pubisher.getText().isEmpty() && !m_Title.getText().isEmpty() && !m_Issue.getText().isEmpty() && !m_Code.getText().isEmpty() && !m_Copies.getText().isEmpty()
                && !m_Isbn.getText().isEmpty() && !m_Pages.getText().isEmpty() && !m_Volume.getText().isEmpty() && !m_Year.getText().isEmpty()) {
            Magazine magazine = new Magazine();
            magazine.AddForm1(m_Title.getText(), m_Pubisher.getText(), m_Copies.getText(), m_Isbn.getText(),
                    m_Issue.getText(), m_Year.getText(), m_Pages.getText(), m_Code.getText(), m_Volume.getText());
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Thesis Form Added or Modified");
            mb_Reset.doClick();
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Incorrect Fields");
        }
    }//GEN-LAST:event_mb_AddActionPerformed

    private void mb_ResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mb_ResetActionPerformed
        m_Code.setText("");
        m_Copies.setText("");
        m_Isbn.setText("");
        m_Issue.setText("");
        m_Pages.setText("");
        m_Pubisher.setText("");
        m_Search.setText("");
        m_Title.setText("");
        m_Volume.setText("");
        m_Year.setText("");
    }//GEN-LAST:event_mb_ResetActionPerformed

    private void mb_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mb_SearchActionPerformed
        try {
            if (!m_Search.getText().isEmpty()) {
                int m = 0;

                while (m != 100) {
                    m++;
                    if (mc_Combo.getSelectedIndex() == 0) {
                        try {

                            File f1 = new File("Resource\\Magazineform" + m + ".txt"); //Creation of File Descriptor for input file
                            String[] words = null;  //Intialize the word Array
                            FileReader fr = new FileReader(f1);  //Creation of File Reader object
                            BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                            String s;
                            System.out.println("Enter Title of the form");
                            String input = m_Search.getText();   // Input word to be searched
                            int count = 0;   //Intialize the word to zero

                            words = br.readLine().split(" ");  //Split the word using space
                            for (String word : words) {
                                if (word.trim().equalsIgnoreCase(input.trim())) //Search for the given word
                                {
                                    count++;
                                    File file = new File("Resource\\MagazineForm" + m + ".txt");
                                    if (m != 100) {
                                        formNoMag = m;
                                    }
                                    BufferedReader br1 = new BufferedReader(new FileReader(file));

                                    String st;
                                    int ite1 = 0;
                                    printText = "";
                                    while ((st = br1.readLine()) != null) {
                                        printText = printText + st + "\n";
                                        st=st.split(":")[1];
                                        if (ite1 == 0) {
                                            m_Title.setText(st);
                                        }
                                        if (ite1 == 1) {
                                            m_Pubisher.setText(st);
                                        }
                                        if (ite1 == 2) {
                                            m_Year.setText(st);
                                        }
                                        if (ite1 == 3) {
                                            m_Volume.setText(st);
                                        }
                                        if (ite1 == 4) {
                                            m_Issue.setText(st);
                                        }
                                        if (ite1 == 5) {
                                            m_Isbn.setText(st);
                                        }
                                        if (ite1 == 6) {
                                            m_Pages.setText(st);
                                        }
                                        if (ite1 == 7) {
                                            m_Copies.setText(st);
                                        }
                                        if (ite1 == 8) {
                                            m_Code.setText(st);
                                        }
                                        ite1++;

                                    }
                                    Print_TextArea.setText(printText);
                                }

                            }

                            if (count != 0) //Check for count not equal to zero
                            {
                                System.out.println("This form title is present in the library collection");
                            } else {
                                System.out.println("The given form title is not present in the library collection");
                            }

                            fr.close();
                        } catch (IOException ex) {

                        }
                    } else if (mc_Combo.getSelectedIndex() == 1) {
                        try {

                            File f1 = new File("Resource\\Magazineform" + m + ".txt"); //Creation of File Descriptor for input file
                            String[] words = null;  //Intialize the word Array
                            FileReader fr = new FileReader(f1);  //Creation of File Reader object
                            BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                            String s;
                            System.out.println("Enter Title of the form");
                            String input = m_Search.getText();   // Input word to be searched
                            int count = 0;   //Intialize the word to zero
                            br.readLine();

                            words = br.readLine().split(" ");  //Split the word using space
                            for (String word : words) {
                                if (word.trim().equalsIgnoreCase(input.trim())) //Search for the given word
                                {
                                    count++;
                                    File file = new File("Resource\\MagazineForm" + m + ".txt");
                                    if (m != 100) {
                                        formNoMag = m;
                                    }
                                    BufferedReader br1 = new BufferedReader(new FileReader(file));

                                    String st;
                                    int ite2 = 0;
                                    printText = "";
                                    while ((st = br1.readLine()) != null) {
                                        printText = printText + st + "\n";
                                        st = st.split(":")[1];
                                        if (ite2 == 0) {
                                            m_Title.setText(st);
                                        }
                                        if (ite2 == 1) {
                                            m_Pubisher.setText(st);
                                        }
                                        if (ite2 == 2) {
                                            m_Year.setText(st);
                                        }
                                        if (ite2 == 3) {
                                            m_Volume.setText(st);
                                        }
                                        if (ite2 == 4) {
                                            m_Issue.setText(st);
                                        }
                                        if (ite2 == 5) {
                                            m_Isbn.setText(st);
                                        }
                                        if (ite2 == 6) {
                                            m_Pages.setText(st);
                                        }
                                        if (ite2 == 7) {
                                            m_Copies.setText(st);
                                        }
                                        if (ite2 == 8) {
                                            m_Code.setText(st);
                                        }
                                        ite2++;
                                    }
                                }

                            }

                            if (count != 0) //Check for count not equal to zero
                            {
                                System.out.println("This form title is present in the library collection");
                            } else {
                                System.out.println("The given form title is not present in the library collection");
                            }

                            fr.close();
                        } catch (IOException ex) {

                        }
                    } else if (mc_Combo.getSelectedIndex() == 2) {
                        try {

                            File f1 = new File("Resource\\Magazineform" + m + ".txt"); //Creation of File Descriptor for input file
                            String[] words = null;  //Intialize the word Array
                            FileReader fr = new FileReader(f1);  //Creation of File Reader object
                            BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                            String s;
                            System.out.println("Enter Title of the form");
                            String input = m_Search.getText();   // Input word to be searched
                            int count = 0;   //Intialize the word to zero

                            words = br.readLine().split(" ");  //Split the word using space
                            for (String word : words) {
                                if (word.trim().contains(input.trim())) //Search for the given word
                                {
                                    count++;
                                    File file = new File("Resource\\MagazineForm" + m + ".txt");
                                    if (m != 100) {
                                        formNoMag = m;
                                    }
                                    BufferedReader br1 = new BufferedReader(new FileReader(file));

                                    String st;
                                    int ite3 = 0;
                                    printText = "";
                                    while ((st = br1.readLine()) != null) {
                                        printText = printText + st + "\n";
                                        st = st.split(":")[1];
                                        if (ite3 == 0) {
                                            m_Title.setText(st);
                                        }
                                        if (ite3 == 1) {
                                            m_Pubisher.setText(st);
                                        }
                                        if (ite3 == 2) {
                                            m_Year.setText(st);
                                        }
                                        if (ite3 == 3) {
                                            m_Volume.setText(st);
                                        }
                                        if (ite3 == 4) {
                                            m_Issue.setText(st);
                                        }
                                        if (ite3 == 5) {
                                            m_Isbn.setText(st);
                                        }
                                        if (ite3 == 6) {
                                            m_Pages.setText(st);
                                        }
                                        if (ite3 == 7) {
                                            m_Copies.setText(st);
                                        }
                                        if (ite3 == 8) {
                                            m_Code.setText(st);
                                        }
                                        ite3++;
                                    }
                                }

                            }

                            if (count != 0) //Check for count not equal to zero
                            {
                                System.out.println("This form title is present in the library collection");
                            } else {
                                System.out.println("The given form title is not present in the library collection");
                            }

                            fr.close();
                        } catch (IOException ex) {

                        }
                    }
                }

            } else {
                JFrame f = new JFrame();
                JOptionPane.showMessageDialog(f, "Incorrect or missing data error");
            }
        } catch (Exception e) {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Form Not Found");
        }

    }//GEN-LAST:event_mb_SearchActionPerformed

    private void m_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_m_SearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_m_SearchActionPerformed

    private void mc_ComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mc_ComboActionPerformed

    }//GEN-LAST:event_mc_ComboActionPerformed

    private void bc_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bc_SearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bc_SearchActionPerformed

    private void bb_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bb_SearchActionPerformed
        try {
            System.out.println(bc_Search.getSelectedIndex());
            int i = 0;
            if (!b_Search.getText().isEmpty()) {
                while (i != 100) {
                    i++;
                    if (bc_Search.getSelectedIndex() == 0) {
                        FileReader fr = null;
                        try {

                            File f1 = new File("Resource\\Bookform" + i + ".txt"); //Creation of File Descriptor for input file
                            String[] words = null;  //Intialize the word Array
                            fr = new FileReader(f1); //Creation of File Reader object
                            BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                            String s;
                            String input = b_Search.getText();   // Input word to be searched
                            int count = 0;   //Intialize the word to zero

                            words = br.readLine().split(" ");  //Split the word using space
                            for (String word : words) {
                                if (word.trim().equalsIgnoreCase(input.trim())) //Search for the given word
                                {
                                    count++;
                                    File file = new File("Resource\\BookForm" + i + ".txt");

                                    BufferedReader br1 = new BufferedReader(new FileReader(file));

                                    String st;
                                    int itee = 0;
                                    printText = "";
                                    while ((st = br1.readLine()) != null) {
                                        printText = printText + st + "\n";
                                        st = st.split(":")[1];
                                        if (i != 100) {
                                            formNoBook = i;
                                        }
                                        i = 100;
                                        if (itee == 0) {
                                            b_Title.setText(st);
                                        }
                                        if (itee == 1) {
                                            b_AuthorName.setText(st);
                                        }
                                        if (itee == 2) {
                                            b_AuthorDob.setText(st);
                                        }
                                        if (itee == 3) {
                                            b_numerous.setText(st);
                                        }
                                        if (itee == 4) {
                                            b_description.setText(st);
                                        }
                                        if (itee == 5) {
                                            b_publishouse.setText(st);
                                        }
                                        if (itee == 6) {
                                            b_publisher.setText(st);
                                        }
                                        if (itee == 7) {
                                            b_year.setText(st);
                                        }
                                        if (itee == 8) {
                                            b_isbn.setText(st);
                                        }
                                        if (itee == 9) {
                                            b_pages.setText(st);
                                        }
                                        if (itee == 10) {
                                            b_copies.setText(st);
                                        }
                                        if (itee == 11) {
                                            b_code.setText(st);
                                        }
                                        itee++;
                                    }
                                }

                            }

                            if (count != 0) //Check for count not equal to zero
                            {
                                JFrame f = new JFrame();
                                JOptionPane.showMessageDialog(f, "Form Searched Successfully");
                            } else {

                            }
                            fr.close();
                        } catch (FileNotFoundException ex) {

                        } catch (IOException ex) {
                            Logger.getLogger(Lib_Frame.class
                                    .getName()).log(Level.SEVERE, null, ex);
                        } finally {
                            try {
                                fr.close();
                            } catch (IOException ex) {
                                Logger.getLogger(Lib_Frame.class
                                        .getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    } else if (bc_Search.getSelectedIndex() == 1) {
                        FileReader fr = null;
                        try {

                            File f1 = new File("Resource\\Bookform" + i + ".txt"); //Creation of File Descriptor for input file
                            String[] words = null;  //Intialize the word Array
                            fr = new FileReader(f1); //Creation of File Reader object
                            BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                            String s;
                            String input = b_Search.getText();   // Input word to be searched
                            int count = 0;   //Intialize the word to zero
                            s = br.readLine();

                            words = br.readLine().split(" ");  //Split the word using space
                            for (String word : words) {
                                if (word.trim().equalsIgnoreCase(input.trim())) //Search for the given word
                                {
                                    count++;
                                    File file = new File("Resource\\BookForm" + i + ".txt");

                                    BufferedReader br1 = new BufferedReader(new FileReader(file));

                                    String st;
                                    int ite = 0;
                                    printText = "";
                                    while ((st = br1.readLine()) != null) {
                                        printText = printText + st + "\n";
                                        st = st.split(":")[1];
                                        if (i != 100) {
                                            formNoBook = i;
                                        }
                                        i = 100;
                                        if (ite == 0) {
                                            b_Title.setText(st);
                                        }
                                        if (ite == 1) {
                                            b_AuthorName.setText(st);
                                        }
                                        if (ite == 2) {
                                            b_AuthorDob.setText(st);
                                        }
                                        if (ite == 3) {
                                            b_numerous.setText(st);
                                        }
                                        if (ite == 4) {
                                            b_description.setText(st);
                                        }
                                        if (ite == 5) {
                                            b_publishouse.setText(st);
                                        }
                                        if (ite == 6) {
                                            b_publisher.setText(st);
                                        }
                                        if (ite == 7) {
                                            b_year.setText(st);
                                        }
                                        if (ite == 8) {
                                            b_isbn.setText(st);
                                        }
                                        if (ite == 9) {
                                            b_pages.setText(st);
                                        }
                                        if (ite == 10) {
                                            b_copies.setText(st);
                                        }
                                        if (ite == 11) {
                                            b_code.setText(st);
                                        }
                                        ite++;
                                    }
                                }

                            }

                            if (count != 0) //Check for count not equal to zero
                            {
                                JFrame f = new JFrame();
                                JOptionPane.showMessageDialog(f, "Form Searched Successfully");
                            }
                            fr.close();
                        } catch (FileNotFoundException ex) {

                        } catch (IOException ex) {
                            Logger.getLogger(Lib_Frame.class
                                    .getName()).log(Level.SEVERE, null, ex);
                        } finally {
                            try {
                                fr.close();
                            } catch (IOException ex) {
                                Logger.getLogger(Lib_Frame.class
                                        .getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    } else if (bc_Search.getSelectedIndex() == 2) {
                        FileReader fr = null;
                        try {

                            File f1 = new File("Resource\\Bookform" + i + ".txt"); //Creation of File Descriptor for input file
                            String[] words = null;  //Intialize the word Array
                            fr = new FileReader(f1); //Creation of File Reader object
                            BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                            String s;
                            String input = b_Search.getText();   // Input word to be searched
                            int count = 0;   //Intialize the word to zero
                            words = br.readLine().split(" ");  //Split the word using space
                            for (String word : words) {
                                if (word.trim().contains(input.trim())) //Search for the given word
                                {
                                    count++;
                                    File file = new File("Resource\\BookForm" + i + ".txt");

                                    BufferedReader br1 = new BufferedReader(new FileReader(file));

                                    String st;
                                    int iteration = 0;
                                    printText = "";
                                    while ((st = br1.readLine()) != null) {
                                        printText = printText + st + "\n";
                                        st = st.split(":")[1];
                                        if (i != 100) {
                                            formNoBook = i;
                                        }
                                        i = 100;
                                        if (iteration == 0) {
                                            b_Title.setText(st);
                                        }
                                        if (iteration == 1) {
                                            b_AuthorName.setText(st);
                                        }
                                        if (iteration == 2) {
                                            b_AuthorDob.setText(st);
                                        }
                                        if (iteration == 3) {
                                            b_numerous.setText(st);
                                        }
                                        if (iteration == 4) {
                                            b_description.setText(st);
                                        }
                                        if (iteration == 5) {
                                            b_publishouse.setText(st);
                                        }
                                        if (iteration == 6) {
                                            b_publisher.setText(st);
                                        }
                                        if (iteration == 7) {
                                            b_year.setText(st);
                                        }
                                        if (iteration == 8) {
                                            b_isbn.setText(st);
                                        }
                                        if (iteration == 9) {
                                            b_pages.setText(st);
                                        }
                                        if (iteration == 10) {
                                            b_copies.setText(st);
                                        }
                                        if (iteration == 11) {
                                            b_code.setText(st);
                                        }
                                        iteration++;
                                    }
                                }

                            }

                            if (count != 0) //Check for count not equal to zero
                            {
                                JFrame f = new JFrame();
                                JOptionPane.showMessageDialog(f, "Form Searched Successfully");
                            }
                            fr.close();
                        } catch (FileNotFoundException ex) {

                        } catch (IOException ex) {

                        } finally {
                            try {
                                fr.close();
                            } catch (IOException ex) {
                                Logger.getLogger(Lib_Frame.class
                                        .getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                }
            } else {
                JFrame f = new JFrame();
                JOptionPane.showMessageDialog(f, "Please Enter The data to Search");
            }
        } catch (Exception e) {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "This Form not Found");
        }
    }//GEN-LAST:event_bb_SearchActionPerformed

    private void b_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_SearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_b_SearchActionPerformed

    private void bb_ModifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bb_ModifyActionPerformed
        if (formNoBook != 0) {
            System.out.println("I am form No" + formNoBook);

            File f = new File("Resource\\BookForm" + formNoBook + ".txt");
            f.delete();
            bb_Add.doClick();
            formNoBook = 0;
            bb_Reset.doClick();
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "First Search The Book to Modify");
        }
    }//GEN-LAST:event_bb_ModifyActionPerformed

    private void a_NumerousBooksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_a_NumerousBooksActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_a_NumerousBooksActionPerformed

    private void a_DOBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_a_DOBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_a_DOBActionPerformed

    private void t_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_SearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t_SearchActionPerformed

    private void tb_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tb_SearchActionPerformed
        try {
            System.out.println(tc_Combo.getSelectedIndex());
            int thi = 0;
            if (!t_Search.getText().isEmpty()) {
                while (thi != 100) {
                    thi++;
                    if (tc_Combo.getSelectedIndex() == 0) {
                        FileReader fr = null;
                        try {

                            File f1 = new File("Resource\\Thesisform" + thi + ".txt"); //Creation of File Descriptor for input file
                            String[] words = null;  //Intialize the word Array
                            fr = new FileReader(f1); //Creation of File Reader object
                            BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                            String s;
                            String input = t_Search.getText();   // Input word to be searched
                            int count = 0;   //Intialize the word to zero

                            words = br.readLine().split(" ");  //Split the word using space
                            for (String word : words) {
                                if (word.trim().equalsIgnoreCase(input.trim())) //Search for the given word
                                {
                                    count++;
                                    File file = new File("Resource\\ThesisForm" + thi + ".txt");

                                    BufferedReader br1 = new BufferedReader(new FileReader(file));

                                    String st;
                                    int iteration = 0;
                                    printText = "";
                                    while ((st = br1.readLine()) != null) {
                                        printText = printText + st + "\n";
                                        st = st.split(":")[1];

                                        if (thi != 100) {
                                            formNoThesis = thi;
                                        }
                                        thi = 100;
                                        if (iteration == 0) {
                                            t_Title.setText(st);
                                        }
                                        if (iteration == 1) {
                                            t_Name.setText(st);
                                        }
                                        if (iteration == 2) {
                                            t_Dob.setText(st);
                                        }
                                        if (iteration == 3) {
                                            t_Numerous.setText(st);
                                        }
                                        if (iteration == 4) {
                                            t_Description.setText(st);
                                        }
                                        if (iteration == 5) {
                                            t_PublishingHouse.setText(st);
                                        }
                                        if (iteration == 6) {
                                            t_Supervisor.setText(st);
                                        }
                                        if (iteration == 7) {
                                            t_Year.setText(st);
                                        }
                                        if (iteration == 8) {
                                            t_Type.setText(st);
                                        }
                                        if (iteration == 9) {
                                            t_Department.setText(st);
                                        }
                                        if (iteration == 10) {
                                            t_University.setText(st);
                                        }
                                        if (iteration == 11) {
                                            t_pages.setText(st);
                                        }
                                        if (iteration == 12) {
                                            t_Copies.setText(st);
                                        }
                                        if (iteration == 13) {
                                            t_code.setText(st);
                                        }
                                        iteration++;
                                    }
                                }

                            }

                            if (count != 0) //Check for count not equal to zero
                            {
                                JFrame f = new JFrame();
                                JOptionPane.showMessageDialog(f, "Form Searched Successfully");
                            }
                            fr.close();
                        } catch (FileNotFoundException ex) {

                        } catch (IOException ex) {

                        } finally {
                            try {
                                fr.close();
                            } catch (IOException ex) {

                            }
                        }
                    } else if (tc_Combo.getSelectedIndex() == 1) {
                        FileReader fr = null;
                        try {

                            File f1 = new File("Resource\\Thesisform" + thi + ".txt"); //Creation of File Descriptor for input file
                            String[] words = null;  //Intialize the word Array
                            fr = new FileReader(f1); //Creation of File Reader object
                            BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                            String s;
                            String input = t_Search.getText();   // Input word to be searched
                            int count = 0;   //Intialize the word to zero
                            br.readLine();

                            words = br.readLine().split(" ");  //Split the word using space
                            for (String word : words) {
                                if (word.trim().equalsIgnoreCase(input.trim())) //Search for the given word
                                {
                                    count++;
                                    File file = new File("Resource\\ThesisForm" + thi + ".txt");

                                    BufferedReader br1 = new BufferedReader(new FileReader(file));

                                    String st;
                                    int iteration = 0;
                                    printText = "";
                                    while ((st = br1.readLine()) != null) {
                                        printText = printText + st + "\n";
                                        st = st.split(":")[1];
                                        if (thi != 100) {
                                            formNoThesis = thi;
                                        }
                                        thi = 100;
                                        if (iteration == 0) {
                                            t_Title.setText(st);
                                        }
                                        if (iteration == 1) {
                                            t_Name.setText(st);
                                        }
                                        if (iteration == 2) {
                                            t_Dob.setText(st);
                                        }
                                        if (iteration == 3) {
                                            t_Numerous.setText(st);
                                        }
                                        if (iteration == 4) {
                                            t_Description.setText(st);
                                        }
                                        if (iteration == 5) {
                                            t_PublishingHouse.setText(st);
                                        }
                                        if (iteration == 6) {
                                            t_Supervisor.setText(st);
                                        }
                                        if (iteration == 7) {
                                            t_Year.setText(st);
                                        }
                                        if (iteration == 8) {
                                            t_Type.setText(st);
                                        }
                                        if (iteration == 9) {
                                            t_Department.setText(st);
                                        }
                                        if (iteration == 10) {
                                            t_University.setText(st);
                                        }
                                        if (iteration == 11) {
                                            t_pages.setText(st);
                                        }
                                        if (iteration == 12) {
                                            t_Copies.setText(st);
                                        }
                                        if (iteration == 13) {
                                            t_code.setText(st);
                                        }
                                        iteration++;
                                    }
                                }

                            }

                            if (count != 0) //Check for count not equal to zero
                            {
                                JFrame f = new JFrame();
                                JOptionPane.showMessageDialog(f, "Form Searched Successfully");
                            }
                            fr.close();
                        } catch (FileNotFoundException ex) {

                        } catch (IOException ex) {

                        } finally {
                            try {
                                fr.close();
                            } catch (IOException ex) {

                            }
                        }
                    } else if (tc_Combo.getSelectedIndex() == 2) {
                        FileReader fr = null;
                        try {

                            File f1 = new File("Resource\\Bookform" + thi + ".txt"); //Creation of File Descriptor for input file
                            String[] words = null;  //Intialize the word Array
                            fr = new FileReader(f1); //Creation of File Reader object
                            BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                            String s;
                            String input = t_Search.getText();   // Input word to be searched
                            int count = 0;   //Intialize the word to zero

                            words = br.readLine().split(" ");  //Split the word using space
                            for (String word : words) {
                                if (word.trim().contains(input.trim())) //Search for the given word
                                {
                                    count++;
                                    File file = new File("Resource\\ThesisForm" + thi + ".txt");

                                    BufferedReader br1 = new BufferedReader(new FileReader(file));

                                    String st;
                                    int iteration = 0;
                                    printText = "";
                                    while ((st = br1.readLine()) != null) {
                                        printText = printText + st + "\n";
                                        st = st.split(":")[1];
                                        if (thi != 100) {
                                            formNoThesis = thi;
                                        }
                                        thi = 100;
                                        if (iteration == 0) {
                                            t_Title.setText(st);
                                        }
                                        if (iteration == 1) {
                                            t_Name.setText(st);
                                        }
                                        if (iteration == 2) {
                                            t_Dob.setText(st);
                                        }
                                        if (iteration == 3) {
                                            t_Numerous.setText(st);
                                        }
                                        if (iteration == 4) {
                                            t_Description.setText(st);
                                        }
                                        if (iteration == 5) {
                                            t_PublishingHouse.setText(st);
                                        }
                                        if (iteration == 6) {
                                            t_Supervisor.setText(st);
                                        }
                                        if (iteration == 7) {
                                            t_Year.setText(st);
                                        }
                                        if (iteration == 8) {
                                            t_Type.setText(st);
                                        }
                                        if (iteration == 9) {
                                            t_Department.setText(st);
                                        }
                                        if (iteration == 10) {
                                            t_University.setText(st);
                                        }
                                        if (iteration == 11) {
                                            t_pages.setText(st);
                                        }
                                        if (iteration == 12) {
                                            t_Copies.setText(st);
                                        }
                                        if (iteration == 13) {
                                            t_code.setText(st);
                                        }
                                        iteration++;
                                    }
                                }

                            }

                            if (count != 0) //Check for count not equal to zero
                            {
                                JFrame f = new JFrame();
                                JOptionPane.showMessageDialog(f, "Form Searched Successfully");
                            } else {

                            }
                            fr.close();
                        } catch (FileNotFoundException ex) {

                        } catch (IOException ex) {

                        } finally {
                            try {
                                fr.close();
                            } catch (IOException ex) {

                            }
                        }
                    }
                }
            } else {
                JFrame f = new JFrame();
                JOptionPane.showMessageDialog(f, "Please Enter The data to Search");
            }
        } catch (Exception e) {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Form Not Found");
        }
    }//GEN-LAST:event_tb_SearchActionPerformed

    private void tc_ComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tc_ComboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tc_ComboActionPerformed

    private void tb_ModifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tb_ModifyActionPerformed
        if (formNoThesis != 0) {
            System.out.println("I am form No" + formNoThesis);

            File f = new File("Resource\\ThesisForm" + formNoThesis + ".txt");
            f.delete();
            tb_Add.doClick();
            formNoThesis = 0;
            tb_Reset.doClick();
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "First Search Thesis to Modify");
        }
    }//GEN-LAST:event_tb_ModifyActionPerformed

    private void a_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_a_SearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_a_SearchActionPerformed

    private void ab_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ab_SearchActionPerformed
        try {
            if (!a_Search.getText().isEmpty()) {
                int aut = 0;
                while (aut != 100) {
                    aut++;
                    if (ac_Search.getSelectedIndex() == 0) {
                        FileReader fr = null;
                        try {
                            int i = 1;
                            File f1 = new File("Resource\\AuthorForm" + aut + ".txt"); //Creation of File Descriptor for input file
                            String[] words = null;  //Intialize the word Array
                            fr = new FileReader(f1); //Creation of File Reader object
                            BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                            String s;
                            String input = a_Search.getText();   // Input word to be searched
                            int count = 0;   //Intialize the word to zero

                            words = br.readLine().split(" ");  //Split the word using space
                            for (String word : words) {
                                if (word.trim().equalsIgnoreCase(input.trim())) //Search for the given word
                                {
                                    count++;
                                    File file = new File("Resource\\AuthorForm" + aut + ".txt");
                                    if (aut != 100) {
                                        formNoAut = aut;
                                    }
                                    BufferedReader br1 = new BufferedReader(new FileReader(file));

                                    String st;
                                    int ite1 = 0;
                                    printText = "";
                                    while ((st = br1.readLine()) != null) {
                                        printText = printText + st + "\n";
                                        st = st.split(":")[1];
                                        if (ite1 == 0) {
                                            a_Name.setText(st);
                                        }
                                        if (ite1 == 1) {
                                            a_DOB.setText(st);
                                        }
                                        if (ite1 == 2) {
                                            a_NumerousBooks.setText(st);
                                        }
                                        if (ite1 == 3) {
                                            a_Description.setText(st);
                                        }
                                        if (ite1 == 4) {
                                            a_PublishHouse.setText(st);
                                        }
                                        ite1++;
                                    }
                                }

                            }

                            fr.close();
                        } catch (FileNotFoundException ex) {

                        } catch (IOException ex) {

                        } finally {
                            try {
                                fr.close();
                            } catch (IOException ex) {

                            }
                        }
                    } else if (ac_Search.getSelectedIndex() == 1) {
                        FileReader fr = null;
                        try {
                            int i = 1;
                            File f1 = new File("Resource\\AuthorForm" + aut + ".txt"); //Creation of File Descriptor for input file
                            String[] words = null;  //Intialize the word Array
                            fr = new FileReader(f1); //Creation of File Reader object
                            BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                            String s;
                            String input = a_Search.getText();   // Input word to be searched
                            int count = 0;   //Intialize the word to zero

                            words = br.readLine().split(" ");  //Split the word using space
                            for (String word : words) {
                                if (word.trim().contains(input.trim())) //Search for the given word
                                {
                                    count++;
                                    File file = new File("Resource\\AuthorForm" + aut + ".txt");
                                    if (aut != 100) {
                                        formNoAut = aut;
                                    }
                                    BufferedReader br1 = new BufferedReader(new FileReader(file));

                                    String st;
                                    int ite1 = 0;
                                    printText = "";
                                    while ((st = br1.readLine()) != null) {
                                        printText = printText + st + "\n";
                                        st = st.split(":")[1];
                                        if (ite1 == 0) {
                                            a_Name.setText(st);
                                        }
                                        if (ite1 == 1) {
                                            a_DOB.setText(st);
                                        }
                                        if (ite1 == 2) {
                                            a_NumerousBooks.setText(st);
                                        }
                                        if (ite1 == 3) {
                                            a_Description.setText(st);
                                        }
                                        if (ite1 == 4) {
                                            a_PublishHouse.setText(st);
                                        }
                                        ite1++;
                                    }
                                }

                            }

                            fr.close();
                        } catch (FileNotFoundException ex) {

                        } catch (IOException ex) {

                        } finally {
                            try {
                                fr.close();
                            } catch (IOException ex) {

                            }
                        }
                    }
                }
            } else {

            }
        } catch (Exception e) {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Form Not Found");
        }


    }//GEN-LAST:event_ab_SearchActionPerformed

    private void ac_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ac_SearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ac_SearchActionPerformed

    private void mb_ModifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mb_ModifyActionPerformed
        if (formNoMag != 0) {
            System.out.println("I am form No" + formNoMag);

            File f = new File("Resource\\MagazineForm" + formNoMag + ".txt");
            f.delete();
            mb_Add.doClick();
            formNoMag = 0;
            mb_Reset.doClick();
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "First Search the Megazine to Modify");
        }
    }//GEN-LAST:event_mb_ModifyActionPerformed

    private void m_PubisherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_m_PubisherActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_m_PubisherActionPerformed

    private void ab_AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ab_AddActionPerformed

        if (!a_Name.getText().isEmpty() && !a_DOB.getText().isEmpty() && !a_Description.getText().isEmpty() && !a_NumerousBooks.getText().isEmpty()
                && !a_PublishHouse.getText().isEmpty()) {
            Author author = new Author();
            author.AddForm1(a_Name.getText(), a_DOB.getText(), a_NumerousBooks.getText(), a_PublishHouse.getText(), a_Description.getText().replaceAll("\n", " "));
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Author Added or Modify Successfully");
            ab_Reset.doClick();
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "Incorrect Fields of Data");
        }
    }//GEN-LAST:event_ab_AddActionPerformed

    private void ab_ModifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ab_ModifyActionPerformed
        if (formNoAut != 0) {
            System.out.println("I am form No" + formNoAut);

            File f = new File("Resource\\AuthorForm" + formNoAut + ".txt");
            f.delete();
            ab_Add.doClick();
            formNoAut = 0;
            ab_Reset.doClick();
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "First Search the Author to Modify");
        }
    }//GEN-LAST:event_ab_ModifyActionPerformed

    private void ab_ResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ab_ResetActionPerformed
        a_DOB.setText("");
        a_Description.setText("");
        a_Name.setText("");
        a_NumerousBooks.setText("");
        a_PublishHouse.setText("");
        a_Search.setText("");
    }//GEN-LAST:event_ab_ResetActionPerformed

    private void t_CopiesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_t_CopiesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_t_CopiesActionPerformed

    private void PrintPanelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PrintPanelActionPerformed
        Book_Panel.setVisible(false);
        Thesis_Panel.setVisible(false);
        Megazine_Panel.setVisible(false);
        Author_Panel.setVisible(false);
        Print_Panel.setVisible(true);

    }//GEN-LAST:event_PrintPanelActionPerformed

    private void ab_Reset1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ab_Reset1ActionPerformed
        if (!Print_TextArea.getText().isEmpty()) {
            try {
                Print_TextArea.print();
            } catch (PrinterException ex) {
                Logger.getLogger(Lib_Frame.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "You have to First Search What you want");
        }
    }//GEN-LAST:event_ab_Reset1ActionPerformed

    private void pc_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pc_SearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pc_SearchActionPerformed

    private void pb_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pb_SearchActionPerformed
        if (!p_Search.getText().isEmpty()) {
            if (pc_Search.getSelectedIndex() == 0) {
                b_Search.setText(p_Search.getText());
                bb_Search.doClick();
                bb_Reset.doClick();
                Print_TextArea.setText(printText);
            } else if (pc_Search.getSelectedIndex() == 1) {
                System.out.println("I am in Megazine");
                m_Search.setText(p_Search.getText());
                mb_Search.doClick();
                mb_Reset.doClick();
                Print_TextArea.setText(printText);
            } else if (pc_Search.getSelectedIndex() == 2) {
                System.out.println("I am in Thesis");
                t_Search.setText(p_Search.getText());
                tb_Search.doClick();
                tb_Reset.doClick();
                Print_TextArea.setText(printText);
            } else if (pc_Search.getSelectedIndex() == 3) {
                a_Search.setText(p_Search.getText());
                ab_Search.doClick();
                ab_Reset.doClick();
                Print_TextArea.setText(printText);
            }
        } else {
            JFrame f = new JFrame();
            JOptionPane.showMessageDialog(f, "You have to First Enter which you want to Search");
        }
    }//GEN-LAST:event_pb_SearchActionPerformed

    private void p_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p_SearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p_SearchActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Lib_Frame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Add_LAuther;
    private javax.swing.JLabel Add_LAuther1;
    private javax.swing.JLabel Add_LAuther2;
    private javax.swing.JLabel Add_LAuther3;
    private javax.swing.JLabel Add_LAuther4;
    private javax.swing.JLabel Add_LAuther5;
    private javax.swing.JLabel Add_LBookName;
    private javax.swing.JLabel Add_LBookName1;
    private javax.swing.JLabel Add_LBookName2;
    private javax.swing.JLabel Add_LBookName3;
    private javax.swing.JLabel Add_LBookName4;
    private javax.swing.JLabel Add_LBookName5;
    private javax.swing.JLabel Add_LCoppies;
    private javax.swing.JLabel Add_LCoppies1;
    private javax.swing.JLabel Add_LCoppies10;
    private javax.swing.JLabel Add_LCoppies11;
    private javax.swing.JLabel Add_LCoppies12;
    private javax.swing.JLabel Add_LCoppies2;
    private javax.swing.JLabel Add_LCoppies3;
    private javax.swing.JLabel Add_LCoppies4;
    private javax.swing.JLabel Add_LCoppies5;
    private javax.swing.JLabel Add_LCoppies6;
    private javax.swing.JLabel Add_LCoppies7;
    private javax.swing.JLabel Add_LCoppies8;
    private javax.swing.JLabel Add_LCoppies9;
    private javax.swing.JLabel Add_LEddition;
    private javax.swing.JLabel Add_LEddition1;
    private javax.swing.JLabel Add_LEddition2;
    private javax.swing.JLabel Add_LEddition3;
    private javax.swing.JLabel Add_LEddition4;
    private javax.swing.JLabel Add_LEddition5;
    private javax.swing.JLabel Add_LIsReserved;
    private javax.swing.JLabel Add_LIsReserved1;
    private javax.swing.JLabel Add_LSerialNumber;
    private javax.swing.JLabel Add_LSerialNumber1;
    private javax.swing.JButton AuthorPanel;
    private javax.swing.JPanel Author_Panel;
    private javax.swing.JButton BookPanel;
    private javax.swing.JPanel Book_Panel;
    private javax.swing.JLabel Date;
    private javax.swing.JPanel DateAndTime_Panel;
    private javax.swing.JButton Exit;
    private javax.swing.JLabel Issue_LAutherName;
    private javax.swing.JLabel Issue_LBookName;
    private javax.swing.JLabel Issue_LStudentId;
    private javax.swing.JLabel Issue_LStudentName;
    private javax.swing.JLabel Issue_LStudentName1;
    private javax.swing.JLabel Line_ButtomLine2;
    private javax.swing.JLabel Line_LButtomLine1;
    private javax.swing.JPanel LogoPanal;
    private javax.swing.JPanel Megazine_Panel;
    private javax.swing.JButton Megazinepanel;
    private javax.swing.JPanel MenuPanal;
    private javax.swing.JLabel Menu_LLine1;
    private javax.swing.JLabel Menu_LLine2;
    private javax.swing.JLabel Menu_LSelectOption;
    private javax.swing.JButton PrintPanel;
    private javax.swing.JPanel Print_Panel;
    private javax.swing.JTextArea Print_TextArea;
    private javax.swing.JLabel Search_LSearchBy;
    private javax.swing.JLabel Search_LSearchBy1;
    private javax.swing.JLabel Search_LSearchBy2;
    private javax.swing.JLabel Search_LSearchBy3;
    private javax.swing.JLabel Search_LSearchBy4;
    private javax.swing.JButton ThesisPanel;
    private javax.swing.JPanel Thesis_Panel;
    private javax.swing.JLabel Time;
    private javax.swing.JTextField a_DOB;
    private javax.swing.JTextArea a_Description;
    private javax.swing.JTextField a_Name;
    private javax.swing.JTextField a_NumerousBooks;
    private javax.swing.JTextField a_PublishHouse;
    private javax.swing.JTextField a_Search;
    private javax.swing.JButton ab_Add;
    private javax.swing.JButton ab_Modify;
    private javax.swing.JButton ab_Reset;
    private javax.swing.JButton ab_Reset1;
    private javax.swing.JButton ab_Search;
    private javax.swing.JComboBox<String> ac_Search;
    private javax.swing.JTextField b_AuthorDob;
    private javax.swing.JTextField b_AuthorName;
    private javax.swing.JTextField b_Search;
    private javax.swing.JTextField b_Title;
    private javax.swing.JTextField b_code;
    private javax.swing.JTextField b_copies;
    private javax.swing.JTextArea b_description;
    private javax.swing.JTextField b_isbn;
    private javax.swing.JTextField b_numerous;
    private javax.swing.JTextField b_pages;
    private javax.swing.JTextField b_publisher;
    private javax.swing.JTextField b_publishouse;
    private javax.swing.JTextField b_year;
    private javax.swing.JButton bb_Add;
    private javax.swing.JButton bb_Modify;
    private javax.swing.JButton bb_Reset;
    private javax.swing.JButton bb_Search;
    private javax.swing.JComboBox<String> bc_Search;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTextField m_Code;
    private javax.swing.JTextField m_Copies;
    private javax.swing.JTextField m_Isbn;
    private javax.swing.JTextField m_Issue;
    private javax.swing.JTextField m_Pages;
    private javax.swing.JTextField m_Pubisher;
    private javax.swing.JTextField m_Search;
    private javax.swing.JTextField m_Title;
    private javax.swing.JTextField m_Volume;
    private javax.swing.JTextField m_Year;
    private javax.swing.JButton mb_Add;
    private javax.swing.JButton mb_Modify;
    private javax.swing.JButton mb_Reset;
    private javax.swing.JButton mb_Search;
    private javax.swing.JComboBox<String> mc_Combo;
    private javax.swing.JTextField p_Search;
    private javax.swing.JButton pb_Search;
    private javax.swing.JComboBox<String> pc_Search;
    private javax.swing.JTextField t_Copies;
    private javax.swing.JTextField t_Department;
    private javax.swing.JTextArea t_Description;
    private javax.swing.JTextField t_Dob;
    private javax.swing.JTextField t_Name;
    private javax.swing.JTextField t_Numerous;
    private javax.swing.JTextField t_PublishingHouse;
    private javax.swing.JTextField t_Search;
    private javax.swing.JTextField t_Supervisor;
    private javax.swing.JTextField t_Title;
    private javax.swing.JTextField t_Type;
    private javax.swing.JTextField t_University;
    private javax.swing.JTextField t_Year;
    private javax.swing.JTextField t_code;
    private javax.swing.JTextField t_pages;
    private javax.swing.JButton tb_Add;
    private javax.swing.JButton tb_Modify;
    private javax.swing.JButton tb_Reset;
    private javax.swing.JButton tb_Search;
    private javax.swing.JComboBox<String> tc_Combo;
    // End of variables declaration//GEN-END:variables
}
