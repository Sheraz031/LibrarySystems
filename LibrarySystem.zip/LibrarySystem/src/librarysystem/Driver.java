package librarysystem;

import java.io.*;
import java.util.Scanner;

public class Driver {

    public static void main(String[] args) throws IOException {
        int selection = 0;
        System.out.println("Enter 1 to add new Form:\nEnter 2 to Search form\nEnter 3 to correct form details");
        Scanner sc = new Scanner(System.in);
        selection = sc.nextInt();
        if (selection == 1) {
            int formselection = 0;
            System.out.println("Enter 1 to add new Book form.\nEnter 2 to add new Thesis form.\nEnter 3 to add new Magazine form.");
            formselection = sc.nextInt();

            if (formselection == 1) {
                Book book = new Book();
                book.AddForm();
            } else if (formselection == 2) {
                Thesis thesis = new Thesis();
                thesis.AddForm();
            } else if (formselection == 3) {
                Magazine magazine = new Magazine();
                magazine.AddForm();
            }

        } else if (selection == 2) {
            int searchSelection = 0;
            System.out.println("Enter 1 to search Book form.\nEnter 2 to search Thesis Form.\nEnter 3 to search Magazine form.");
            searchSelection = sc.nextInt();
            Scanner sc1 = new Scanner(System.in);
            if (searchSelection == 1) {
                int i = 1;
                File f1 = new File("Resource\\Bookform" + i + ".txt"); //Creation of File Descriptor for input file
                String[] words = null;  //Intialize the word Array
                FileReader fr = new FileReader(f1);  //Creation of File Reader object
                BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                String s;
                System.out.println("Enter Title of the form");
                String input = sc1.nextLine();   // Input word to be searched
                int count = 0;   //Intialize the word to zero
                while ((s = br.readLine()) != null) //Reading Content from the file
                {
                    words = s.split(" ");  //Split the word using space
                    for (String word : words) {
                        if (word.equals(input)) //Search for the given word
                        {
                            count++;
                            File file = new File("Resource\\Bookform" + i + ".txt");

                            BufferedReader br1 = new BufferedReader(new FileReader(file));

                            String st;
                            while ((st = br1.readLine()) != null) {
                                System.out.println(st);
                            }
                        }

                    }
                }
                if (count != 0) //Check for count not equal to zero
                {
                    System.out.println("This form title is present in the library collection ");
                } else {
                    System.out.println("The given form title is not present in the library collection");
                }

                fr.close();
            } else if (searchSelection == 2) {
                int i = 1;
                File f1 = new File("src\\Resource\\ThesisForm1.txt"); //Creation of File Descriptor for input file
                String[] words = null;  //Intialize the word Array
                FileReader fr = new FileReader(f1);  //Creation of File Reader object
                BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                String s;
                System.out.println("Enter Title of the form");
                String input = sc1.nextLine();   // Input word to be searched
                int count = 0;   //Intialize the word to zero
                while ((s = br.readLine()) != null) //Reading Content from the file
                {
                    words = s.split(" ");  //Split the word using space
                    for (String word : words) {
                        if (word.equals(input)) //Search for the given word
                        {
                            count++;
                            File file = new File("ThesisForm1.txt");

                            BufferedReader br1 = new BufferedReader(new FileReader(file));

                            String st;
                            while ((st = br1.readLine()) != null) {
                                System.out.println(st);
                            }
                        }

                    }
                }
                if (count != 0) //Check for count not equal to zero
                {
                    System.out.println("This form title is present in the library collection");
                } else {
                    System.out.println("The given form title is not present in the library collection");
                }

                fr.close();
            } else if (searchSelection == 3) {
                int i = 1;
                File f1 = new File("src\\Resource\\Magazineform" + i + ".txt"); //Creation of File Descriptor for input file
                String[] words = null;  //Intialize the word Array
                FileReader fr = new FileReader(f1);  //Creation of File Reader object
                BufferedReader br = new BufferedReader(fr); //Creation of BufferedReader object
                String s;
                System.out.println("Enter Title of the form");
                String input = sc1.nextLine();   // Input word to be searched
                int count = 0;   //Intialize the word to zero
                while ((s = br.readLine()) != null) //Reading Content from the file
                {
                    words = s.split(" ");  //Split the word using space
                    for (String word : words) {
                        if (word.equals(input)) //Search for the given word
                        {
                            count++;
                            File file = new File("MagazineForm1.txt");

                            BufferedReader br1 = new BufferedReader(new FileReader(file));

                            String st;
                            while ((st = br1.readLine()) != null) {
                                System.out.println(st);
                            }
                        }

                    }
                }
                if (count != 0) //Check for count not equal to zero
                {
                    System.out.println("This form title is present in the library collection");
                } else {
                    System.out.println("The given form title is not present in the library collection");
                }

                fr.close();
            }
        } else if (selection == 3) {

        }

    }

}
