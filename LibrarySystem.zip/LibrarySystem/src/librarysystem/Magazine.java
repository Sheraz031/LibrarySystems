package librarysystem;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Magazine
{
    String title;
    String publisher;
    int year;
    int volume;
    int issue;
    String ISBN;
    int numberOfPages;
    int numberOfCopies;
    String referenceCode;

    public void AddForm()
    {
        Scanner sc = new Scanner(System.in);
        Scanner sc1=new Scanner(System.in);

        System.out.println("Enter Title");
        title = sc.nextLine();

        System.out.println("Enter Publisher");
        publisher = sc.nextLine();
        System.out.println("Enter Year");
        year = sc1.nextInt();
        System.out.println("Enter Volume");
        volume = sc1.nextInt();
        System.out.println("Enter issue");
        issue = sc1.nextInt();
        System.out.println("Enter ISBN");
        ISBN = sc.nextLine();
        System.out.println("Enter Number of Pages:");
        numberOfPages = sc1.nextInt();
        System.out.println("Enter Number of Copies:");
        numberOfCopies = sc1.nextInt();
        sc.reset();
        System.out.println("Enter Reference Code:");
        referenceCode = sc.nextLine();

        try {
            File file = new File("Resource\\MagazineForm1" + ".txt");
            int increase = 1;
            //check reciept number exist before and increase one number of new reciept
            while (file.exists()) {
                increase++;
                file = new File("Resource\\MagazineForm" + increase + ".txt");
            }
            //if reciept number doesnt exist before this piece of code will be executed
            if (!file.exists()) {
                try {

                    String content = null;
                    file.createNewFile();

                    //creates new file through File writer and edit through buffered writer
                    FileWriter fw = new FileWriter(file.getAbsoluteFile());
                    BufferedWriter bw = new BufferedWriter(fw);
                    //writing to a file
                    bw.write("Title: " + title +"\nPublisher: " + publisher + "\nYear: " + year +"\nVolume: "+volume+
                            "\nIssue: "+issue+ "\nISBN: " + ISBN + "\nNumber of Pages: " + numberOfPages +
                            "\nNumber of Copies: " + numberOfCopies + "\nReference Code: " + referenceCode);

                    bw.close();

                } catch (IOException e) {
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
     public void AddForm1(String title,String publisher,String copies,String Isbn,String issue,String year,String page,String refcode,String volume)
    {
       

        try {
            File file = new File("Resource\\MagazineForm1" + ".txt");
            int increase = 1;
            //check reciept number exist before and increase one number of new reciept
            while (file.exists()) {
                increase++;
                file = new File("Resource\\MagazineForm" + increase + ".txt");
            }
            //if reciept number doesnt exist before this piece of code will be executed
            if (!file.exists()) {
                try {

                    String content = null;
                    file.createNewFile();

                    //creates new file through File writer and edit through buffered writer
                    FileWriter fw = new FileWriter(file.getAbsoluteFile());
                    BufferedWriter bw = new BufferedWriter(fw);
                    //writing to a file
                    bw.write("Title: " + title +"\nPublisher: " + publisher + "\nYear: " + year +"\nVolume: "+volume+
                            "\nIssue: "+issue+ "\nISBN: " + Isbn + "\nNumber of Pages: " + page +
                            "\nNumber of Copies: " + copies + "\nReference Code: " + refcode);

                    bw.close();

                } catch (IOException e) {
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
