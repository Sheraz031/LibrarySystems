package librarysystem;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Author {

    String name;
    String dob;
    int numerousBooks;
    String description;
    String publishingHouses;

    public Author() {
    }

    void AuthorDetails() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Name:");
        name = sc.nextLine();
        System.out.println("Enter Author DOB:");
        dob = sc.nextLine();
        System.out.println("Enter Author NumerousBooks:");
        name = sc.nextLine();

        System.out.println("Enter Description of author's work:");
        description = sc.nextLine();
        System.out.println("Enter Collaborating Publishing Houses:");
        publishingHouses = sc.nextLine();

    }

    public void AddForm() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Name:");
        name = sc.nextLine();
        System.out.println("Enter Author DOB:");
        dob = sc.nextLine();
        System.out.println("Enter Author NumerousBooks:");
        name = sc.nextLine();

        System.out.println("Enter Description of author's work:");
        description = sc.nextLine();
        System.out.println("Enter Collaborating Publishing Houses:");
        publishingHouses = sc.nextLine();
        try {
            File file = new File("Resource\\AuthorForm1" + ".txt");
            int increase = 1;
            //check reciept number exist before and increase one number of new reciept
            while (file.exists()) {
                increase++;
                file = new File("Resource\\AuthorForm" + increase + ".txt");
            }
            //if reciept number doesnt exist before this piece of code will be executed
            if (!file.exists()) {
                try {

                    String content = null;
                    file.createNewFile();

                    //creates new file through File writer and edit through buffered writer
                    FileWriter fw = new FileWriter(file.getAbsoluteFile());
                    BufferedWriter bw = new BufferedWriter(fw);
                    //writing to a file
                    bw.write("Author Name: " + name + "\nAuthor Dob: " + dob + "\nAuthor Numerous Books: " + numerousBooks + "\nAuthor Work Description:" + description + "\nAuthor Publishing Houses: " + publishingHouses);

                    bw.close();

                } catch (IOException e) {
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void AddForm1(String name, String dob, String numerous, String publishhouse, String description) {
        try {
            File file = new File("Resource\\AuthorForm1" + ".txt");
            int increase = 1;
            //check reciept number exist before and increase one number of new reciept
            while (file.exists()) {
                increase++;
                file = new File("Resource\\AuthorForm" + increase + ".txt");
            }
            //if reciept number doesnt exist before this piece of code will be executed
            if (!file.exists()) {
                try {

                    String content = null;
                    file.createNewFile();

                    //creates new file through File writer and edit through buffered writer
                    FileWriter fw = new FileWriter(file.getAbsoluteFile());
                    BufferedWriter bw = new BufferedWriter(fw);
                    //writing to a file
                    bw.write("Author Name: " + name + "\nAuthor DOB: " + dob
                            + "\nAuthor Numerous Books: " + numerous + "\nAuthor Work Description:" + description
                            + "\nAuthor Publishing Houses: " + publishhouse);

                    bw.close();

                } catch (IOException e) {
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
